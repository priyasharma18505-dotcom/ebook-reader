
export interface TOCItem {
    label: string;
    href: string;
    subitems?: TOCItem[];
    // For progress tracking
    id?: number;
    type?: string[];
}

export interface Section {
    id: string | number;
    load: () => Promise<string> | string;
    unload?: () => void;
    createDocument?: () => Promise<Document>;
    size: number;
    cfi?: string;
    linear?: string;
    pageSpread?: 'left' | 'right' | 'center';
    resolveHref?: (href: string) => string;
    mediaOverlay?: any;
    [key: string]: any;
}

export interface Book {
    metadata: {
        title?: string;
        author?: { name: string }[] | { name: string };
        [key: string]: any;
    };
    sections: Section[];
    toc?: TOCItem[];
    pageList?: TOCItem[];
    landmarks?: TOCItem[];
    rendition?: {
        layout?: 'reflowable' | 'pre-paginated';
        spread?: 'none' | 'auto' | 'landscape' | 'portrait' | 'both';
        viewport?: string;
    };
    dir?: 'ltr' | 'rtl';
    getCover?: () => Promise<Blob | null>;
    splitTOCHref?: (href: string) => (string | number)[];
    getTOCFragment?: (doc: Document, id: any) => HTMLElement | null;
    resolveHref?: (href: string) => ({ index: number; anchor: (doc: Document) => any } | null) | Promise<{ index: number; anchor: (doc: Document) => any } | undefined>;
    isExternal?: (uri: string) => boolean;
    destroy?: () => void;
    [key: string]: any;
}

export interface Renderer extends HTMLElement {
    goTo(target: any): Promise<void>;
    scrollToAnchor(range: Range, select?: boolean): Promise<void>;
    getContents(): Array<{ doc: Document; [key: string]: any }>;
    [key: string]: any;
}

export interface BookView {
    renderer: Renderer;
    open: (book: Book) => void;
    init: (options: { lastLocation?: any; showTextStart?: boolean }) => Promise<void>;
    goTo: (target: any) => Promise<any>;
    goLeft: () => void;
    goRight: () => void;
    goToFraction: (fraction: number) => void;
    getSectionFractions: () => number[];
    destroy: () => void;
    addEventListener: (event: string, handler: (e: any) => void) => void;
    removeEventListener: (event: string, handler: (e: any) => void) => void;
    [key: string]: any;
}
