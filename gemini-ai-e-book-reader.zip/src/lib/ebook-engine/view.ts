
import type { Book, BookView, Renderer, TOCItem } from './types';
import * as CFI from './parsers/epubcfi';
import { TOCProgress, SectionProgress } from './core/progress';
import { Overlayer } from './ui/overlayer';
import { textWalker } from './utils/text-walker';
import { TTS } from './core/tts';

const languageInfo = (lang?: string | string[]): {
    canonical?: string;
    locale?: Intl.Locale;
    isCJK?: boolean;
    direction?: 'ltr' | 'rtl';
} => {
    if (!lang) return {};
    const langString = Array.isArray(lang) ? lang[0] : lang;
    try {
        const canonical = Intl.getCanonicalLocales(langString)[0];
        const locale = new Intl.Locale(canonical);
        const isCJK = ['zh', 'ja', 'ko'].includes(locale.language);
        const direction = (locale as any).getTextInfo?.()?.direction || (locale as any).textInfo?.direction;
        return { canonical, locale, isCJK, direction };
    } catch (e) {
        console.warn(e);
        return {};
    }
};

class CursorAutohider {
    #timeout: number | undefined;
    #el: HTMLElement;
    #check: () => boolean;
    #state: { hidden?: boolean; x?: number; y?: number };

    constructor(el: HTMLElement, check: () => boolean, state: {} = {}) {
        this.#el = el;
        this.#check = check;
        this.#state = state;
        if (this.#state.hidden) this.hide();
        this.#el.addEventListener('mousemove', (e) => {
            const { screenX, screenY } = e;
            if (screenX === this.#state.x && screenY === this.#state.y) return;
            this.#state.x = screenX;
            this.#state.y = screenY;
            this.show();
            if (this.#timeout) clearTimeout(this.#timeout);
            if (check()) this.#timeout = window.setTimeout(this.hide.bind(this), 1000);
        }, false);
    }

    cloneFor(el: HTMLElement): CursorAutohider {
        return new CursorAutohider(el, this.#check, this.#state);
    }

    hide(): void {
        this.#el.style.cursor = 'none';
        this.#state.hidden = true;
    }

    show(): void {
        this.#el.style.removeProperty('cursor');
        this.#state.hidden = false;
    }
}

class History extends EventTarget {
    #arr: any[] = [];
    #index: number = -1;

    pushState(x: any): void {
        const last = this.#arr[this.#index];
        if (last === x || (last?.fraction !== undefined && last.fraction === x.fraction)) return;
        this.#arr[++this.#index] = x;
        this.#arr.length = this.#index + 1;
        this.dispatchEvent(new Event('index-change'));
    }

    replaceState(x: any): void {
        this.#arr[this.#index] = x;
    }

    back(): void {
        if (this.#index <= 0) return;
        const detail = { state: this.#arr[this.#index - 1] };
        this.#index--;
        this.dispatchEvent(new CustomEvent('popstate', { detail }));
        this.dispatchEvent(new Event('index-change'));
    }

    forward(): void {
        if (this.#index >= this.#arr.length - 1) return;
        const detail = { state: this.#arr[this.#index + 1] };
        this.#index++;
        this.dispatchEvent(new CustomEvent('popstate', { detail }));
        this.dispatchEvent(new Event('index-change'));
    }

    get canGoBack(): boolean {
        return this.#index > 0;
    }

    get canGoForward(): boolean {
        return this.#index < this.#arr.length - 1;
    }

    clear(): void {
        this.#arr = [];
        this.#index = -1;
    }
}

const SEARCH_PREFIX = 'foliate-search:';

export class View extends EventTarget implements BookView {
    #sectionProgress?: SectionProgress;
    #tocProgress?: TOCProgress;
    #pageProgress?: TOCProgress;
    #searchResults: Map<number, { value: string }[]> = new Map();

    public book!: Book;
    public renderer!: Renderer;
    public isFixedLayout = false;
    public lastLocation: any;
    public history = new History();
    public tts?: TTS;
    public mediaOverlay?: any;
    public language: ReturnType<typeof languageInfo> = {};

    constructor() {
        super();
        this.history.addEventListener('popstate', async (event: Event) => {
            const detail = (event as CustomEvent).detail;
            const resolved = await this.resolveNavigation(detail.state);
            if (resolved) {
                this.renderer.goTo(resolved);
            }
        });
    }

    async open(book: Book) {
        this.book = book;
        this.language = languageInfo(book.metadata?.language);

        if (book.splitTOCHref && book.getTOCFragment) {
            const ids = book.sections.map(s => s.id);
            this.#sectionProgress = new SectionProgress(book.sections, 1500, 1600);
            const splitHref = book.splitTOCHref.bind(book);
            const getFragment = book.getTOCFragment.bind(book);
            this.#tocProgress = new TOCProgress();
            await this.#tocProgress.init({ toc: book.toc ?? [], ids, splitHref, getFragment });
            this.#pageProgress = new TOCProgress();
            await this.#pageProgress.init({ toc: book.pageList ?? [], ids, splitHref, getFragment });
        }

        this.isFixedLayout = this.book.rendition?.layout === 'pre-paginated';
        if (this.isFixedLayout) {
            await import('./ui/fixed-layout');
            this.renderer = document.createElement('foliate-fxl') as Renderer;
        } else {
            await import('./ui/paginator');
            this.renderer = document.createElement('foliate-paginator') as Renderer;
        }

        this.renderer.setAttribute('exportparts', 'head,foot,filter');
        this.renderer.addEventListener('load', (e: Event) => this.#onLoad((e as CustomEvent).detail));
        this.renderer.addEventListener('relocate', (e: Event) => this.#onRelocate((e as CustomEvent).detail));
        this.renderer.addEventListener('create-overlayer', (e: Event) =>
            (e as CustomEvent).detail.attach(this.#createOverlayer((e as CustomEvent).detail)));
        
        (this.renderer as any).open(book);
    }
    
    destroy(): void {
        (this.renderer as any)?.destroy();
        this.renderer?.remove();
        this.#sectionProgress = undefined;
        this.#tocProgress = undefined;
        this.#pageProgress = undefined;
        this.#searchResults.clear();
        this.lastLocation = null;
        this.history.clear();
        this.tts = undefined;
        this.mediaOverlay = undefined;
        this.book?.destroy?.();
    }

    async goToTextStart(): Promise<void> {
        const target = this.book.landmarks?.find(m => m.type?.includes('bodymatter') || m.type?.includes('text'))?.href
            ?? this.book.sections.findIndex(s => s.linear !== 'no');
        await this.goTo(target);
    }

    async init({ lastLocation, showTextStart }: { lastLocation?: any; showTextStart?: boolean }): Promise<void> {
        const resolved = lastLocation ? await this.resolveNavigation(lastLocation) : null;
        if (resolved) {
            await this.renderer.goTo(resolved);
            this.history.pushState(lastLocation);
        } else if (showTextStart) {
            await this.goToTextStart();
        } else {
            this.history.pushState(0);
            await this.renderer.goTo({ index: 0, anchor: 0 });
        }
    }

    #emit(name: string, detail: any, cancelable?: boolean) {
        return this.dispatchEvent(new CustomEvent(name, { detail, cancelable }));
    }

    #onRelocate({ reason, range, index, fraction, size }: any): void {
        const progress = this.#sectionProgress?.getProgress(index, fraction, size) ?? {};
        const tocItem = this.#tocProgress?.getProgress(index, range);
        const pageItem = this.#pageProgress?.getProgress(index, range);
        const cfi = this.getCFI(index, range);
        this.lastLocation = { ...progress, tocItem, pageItem, cfi, range };
        if (reason === 'snap' || reason === 'page' || reason === 'scroll') {
            this.history.replaceState(cfi);
        }
        this.#emit('relocate', this.lastLocation);
    }

    #onLoad({ doc, index }: { doc: Document, index: number }): void {
        doc.documentElement.lang ||= this.language.canonical ?? '';
        if (!this.language.isCJK) {
            doc.documentElement.dir ||= this.language.direction ?? '';
        }
        this.#handleLinks(doc, index);
        // This feature was implemented in a way that caused a crash. Disabling for now.
        // The check was on a non-existent element attribute.
        new CursorAutohider(doc.documentElement, () => false);
        this.#emit('load', { doc, index });
    }

    #handleLinks(doc: Document, index: number): void {
        const { book } = this;
        const section = book.sections[index];
        doc.addEventListener('click', e => {
            const a = (e.target as Element).closest('a[href]');
            if (!a) return;
            e.preventDefault();
            const href_ = a.getAttribute('href')!;
            const href = section?.resolveHref?.(href_) ?? href_;
            if (book?.isExternal?.(href)) {
                Promise.resolve(this.#emit('external-link', { a, href }, true))
                    .then(x => x ? window.open(href, '_blank') : null)
                    .catch(e => console.error(e));
            } else {
                Promise.resolve(this.#emit('link', { a, href }, true))
                    .then(x => x ? this.goTo(href) : null)
                    .catch(e => console.error(e));
            }
        });
    }

    async addAnnotation(annotation: { value: string }, remove?: boolean): Promise<{ index: number, label: string } | undefined> {
        const { value } = annotation;
        let resolved;
        try {
            resolved = await this.resolveNavigation(value.startsWith(SEARCH_PREFIX) ? value.substring(SEARCH_PREFIX.length) : value);
        } catch(e) {
            console.warn(`Could not resolve annotation target: ${value}`, e);
            return;
        }

        if (!resolved) return;
        
        const { index, anchor } = resolved;
        const overlayerInfo = this.#getOverlayer(index);
        
        if (overlayerInfo) {
            const { overlayer, doc } = overlayerInfo;
            if (remove) {
                overlayer.remove(value);
            } else {
                const range = doc ? anchor(doc) : anchor;
                if (value.startsWith(SEARCH_PREFIX)) {
                     overlayer.add(value, range, Overlayer.outline);
                } else {
                    const draw = (func: any, opts: any) => overlayer.add(value, range, func, opts);
                    this.#emit('draw-annotation', { draw, annotation, doc, range });
                }
            }
        }
        
        const tocItem = this.#tocProgress?.getProgress(index, null);
        const label = tocItem?.label ?? `Section ${index + 1}`;
        return { index, label };
    }

    deleteAnnotation(annotation: { value: string }): Promise<any> {
        return this.addAnnotation(annotation, true);
    }

    #getOverlayer(index: number): { overlayer: Overlayer, doc: Document } | undefined {
        const contents = this.renderer.getContents();
        // Fix: Safely access optional 'overlayer' property.
        const content = contents.find((x: any) => x.index === index && x.overlayer);
        return content as { overlayer: Overlayer, doc: Document } | undefined;
    }
    
    #createOverlayer({ doc, index }: { doc: Document, index: number }): Overlayer {
        const overlayer = new Overlayer();
        doc.addEventListener('click', e => {
            const [value, range] = overlayer.hitTest(e as MouseEvent);
            if (value && !String(value).startsWith(SEARCH_PREFIX)) {
                this.#emit('show-annotation', { value, index, range });
            }
        }, false);

        const list = this.#searchResults.get(index);
        if (list) {
            for (const item of list) {
                this.addAnnotation(item);
            }
        }
        this.#emit('create-overlay', { index });
        return overlayer;
    }
    
    async goTo(target: any): Promise<{ index: number, anchor: any } | undefined> {
        const resolved = await this.resolveNavigation(target);
        try {
            if (resolved) {
                await this.renderer.goTo(resolved);
                this.history.pushState(target);
            }
            return resolved;
        } catch (e) {
            console.error(e);
            console.error(`Could not go to ${target}`);
        }
    }

    getCFI(index: number, range: Range | null): string {
        const baseCFI = this.book.sections[index]?.cfi ?? CFI.fake.fromIndex(index);
        if (!range) return baseCFI;
        return CFI.joinIndir(baseCFI, CFI.fromRange(range));
    }

    async resolveNavigation(target: any): Promise<{ index: number, anchor: any } | undefined> {
        try {
            if (typeof target === 'number') return { index: target, anchor: () => 0 };
            if (typeof target?.fraction === 'number') {
                const [index, anchor] = this.#sectionProgress!.getSection(target.fraction);
                return { index, anchor };
            }
            if (typeof target === 'string' && CFI.isCFI.test(target)) return (this.book as any).resolveCFI?.(target);
            if(this.book.resolveHref) return await this.book.resolveHref(target);
        } catch (e) {
            console.error(e);
            console.error(`Could not resolve target ${target}`);
        }
    }
    
    goToFraction(frac: number): void {
        if (!this.#sectionProgress) return;
        const [index, anchor] = this.#sectionProgress.getSection(frac);
        this.renderer.goTo({ index, anchor });
        this.history.pushState({ fraction: frac });
    }

    getSectionFractions(): number[] {
        return (this.#sectionProgress?.sectionFractions ?? []).map(x => x + Number.EPSILON);
    }
    
    goLeft(): void {
        this.book.dir === 'rtl' ? (this.renderer as any).next() : (this.renderer as any).prev();
    }
    goRight(): void {
        this.book.dir === 'rtl' ? (this.renderer as any).prev() : (this.renderer as any).next();
    }
    
    async prev(): Promise<void> {
        await (this.renderer as any).prev();
    }
    
    async next(): Promise<void> {
        await (this.renderer as any).next();
    }
}
