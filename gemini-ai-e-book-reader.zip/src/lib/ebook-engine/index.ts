

import type { Book } from './types';
import { MOBI, isMOBI } from './parsers/mobi';
import { makeFB2 } from './parsers/fb2';
import { makeComicBook } from './parsers/comic-book';
import { EPUB } from './parsers/epub';

const isZip = async (file: File): Promise<boolean> => {
    const arr = new Uint8Array(await file.slice(0, 4).arrayBuffer());
    return arr[0] === 0x50 && arr[1] === 0x4b && arr[2] === 0x03 && arr[3] === 0x04;
};

const isPDF = async (file: File): Promise<boolean> => {
    const arr = new Uint8Array(await file.slice(0, 5).arrayBuffer());
    return arr[0] === 0x25 && arr[1] === 0x50 && arr[2] === 0x44 && arr[3] === 0x46 && arr[4] === 0x2d;
};

const isCBZ = ({ name, type }: File): boolean =>
    type === 'application/vnd.comicbook+zip' || name.toLowerCase().endsWith('.cbz');

const isFB2File = ({ name, type }: File): boolean =>
    type === 'application/x-fictionbook+xml' || name.toLowerCase().endsWith('.fb2');

const isFBZ = ({ name, type }: File): boolean =>
    type === 'application/x-zip-compressed-fb2' || name.toLowerCase().endsWith('.fb2.zip') || name.toLowerCase().endsWith('.fbz');

const makeZipLoader = async (file: File) => {
    // @ts-ignore
    const { configure, ZipReader, BlobReader, TextWriter, BlobWriter } = await import('../vendor/zip.js');
    configure({ useWebWorkers: false });
    const reader = new ZipReader(new BlobReader(file));
    const entries = await reader.getEntries();
    const map = new Map(entries.map((entry: any) => [entry.filename, entry]));
    const load = (f: Function) => (name: string, ...args: any[]) =>
        map.has(name) ? f(map.get(name), ...args) : null;
    const loadText = load((entry: any) => entry.getData(new TextWriter()));
    const loadBlob = load((entry: any, type: string) => entry.getData(new BlobWriter(type)));
    const getSize = (name: string) => map.get(name)?.uncompressedSize ?? 0;
    return { entries, loadText, loadBlob, getSize };
};

export class ResponseError extends Error { }
export class NotFoundError extends Error { }
export class UnsupportedTypeError extends Error { }

const fetchFile = async (url: string): Promise<File> => {
    const res = await fetch(url);
    if (!res.ok) {
        // Fix: Remove the second argument (options object with 'cause') from the Error constructor for better compatibility.
        throw new ResponseError(`${res.status} ${res.statusText}`);
    }
    return new File([await res.blob()], new URL(res.url).pathname);
};

export const makeBook = async (file: File | string): Promise<Book> => {
    if (typeof file === 'string') {
        file = await fetchFile(file);
    }

    if (!(file instanceof File) || !file.size) {
        throw new NotFoundError('File not found or is empty');
    }

    let book: Book | undefined;

    if (await isZip(file)) {
        const loader = await makeZipLoader(file);
        if (isCBZ(file)) {
            // Fix: Cast loader properties to 'any' to satisfy ComicBookLoader interface.
            book = makeComicBook(loader as any, file);
        } else if (isFBZ(file)) {
            // Fix: Cast entry to 'any' to access the 'filename' property.
            const entry = loader.entries.find((entry: any) => (entry.filename as string).toLowerCase().endsWith('.fb2'));
            const blob = await loader.loadBlob((entry ?? loader.entries[0] as any).filename);
            if (blob) {
                book = await makeFB2(blob);
            }
        } else {
            book = await new EPUB(loader).init();
        }
    } else if (await isPDF(file)) {
        throw new UnsupportedTypeError('PDF files are not supported in this version.');
    } else if (await isMOBI(file)) {
        // @ts-ignore
        const fflate = await import('../vendor/fflate.js');
        // Fix: Cast the result to 'Book' to satisfy the return type.
        book = await new MOBI({ unzlib: fflate.unzlibSync }).open(file) as Book;
    } else if (isFB2File(file)) {
        book = await makeFB2(file);
    }
    
    if (!book) {
        throw new UnsupportedTypeError('File type not supported or file is corrupted.');
    }
    return book;
};