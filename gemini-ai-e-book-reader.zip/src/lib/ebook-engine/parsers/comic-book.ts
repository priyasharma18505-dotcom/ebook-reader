
import type { Book } from '../types';

interface ZipEntry {
    filename: string;
    [key: string]: any;
}

interface ComicBookLoader {
    entries: ZipEntry[];
    loadBlob: (name: string) => Promise<Blob>;
    getSize: (name: string) => number;
}

export const makeComicBook = ({ entries, loadBlob, getSize }: ComicBookLoader, file: File): Book => {
    const cache = new Map<string, string>();
    const urls = new Map<string, string[]>();

    const load = async (name: string): Promise<string> => {
        if (cache.has(name)) {
            return cache.get(name)!;
        }
        const blob = await loadBlob(name);
        const src = URL.createObjectURL(blob);
        const pageContent = `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body style="margin: 0"><img src="${src}" style="display: block; width: 100vw; height: 100vh; object-fit: contain;"></body></html>`;
        const pageBlob = new Blob([pageContent], { type: 'text/html' });
        const page = URL.createObjectURL(pageBlob);
        
        urls.set(name, [src, page]);
        cache.set(name, page);
        return page;
    };

    const unload = (name: string): void => {
        urls.get(name)?.forEach?.(url => URL.revokeObjectURL(url));
        urls.delete(name);
        cache.delete(name);
    };

    const exts = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.svg', '.jxl', '.avif'];
    const files = entries
        .map(entry => entry.filename)
        .filter(name => !name.startsWith('__MACOSX')) // Exclude macOS resource fork files
        .filter(name => exts.some(ext => name.toLowerCase().endsWith(ext)))
        .sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }));
        
    if (!files.length) {
        throw new Error('No supported image files in archive');
    }

    const book: Book = {
        metadata: {
            title: file.name
        },
        sections: files.map(name => ({
            id: name,
            load: () => load(name),
            unload: () => unload(name),
            createDocument: async () => {
                const url = await load(name);
                const response = await fetch(url);
                const text = await response.text();
                return new DOMParser().parseFromString(text, 'text/html');
            },
            size: getSize(name),
        })),
        toc: files.map(name => ({
            label: name,
            href: name,
        })),
        rendition: {
            layout: 'pre-paginated'
        },
        getCover: () => loadBlob(files[0]),
        resolveHref: href => {
            const index = book.sections.findIndex(s => s.id === href);
            return { index, anchor: () => 0 };
        },
        splitTOCHref: href => [href, ''],
        getTOCFragment: (doc: Document) => doc.documentElement,
        destroy: () => {
            for (const arr of urls.values()) {
                for (const url of arr) {
                    URL.revokeObjectURL(url);
                }
            }
        }
    };

    return book;
};
