

// A lot of the logic here is complex and deeply tied to the EPUB CFI spec.
// Using `any` in some places is a pragmatic choice to avoid overly complex and
// potentially incorrect type definitions for the deeply nested CFI structures.
// The core functions are now typed for better integration.

const findIndices = (arr: any[], f: (x: any, i: number, a: any[]) => boolean): number[] =>
    arr.map((x, i, a) => f(x, i, a) ? i : null).filter(x => x != null) as number[];

const splitAt = (arr: any[], is: number[]) => [-1, ...is, arr.length].reduce(
    (acc: { xs: any[][], a: number }, b: number) => ({
        xs: acc.xs?.concat([arr.slice(acc.a + 1, b)]) ?? [],
        a: b
    }),
    { xs: [], a: 0 }
).xs;

const concatArrays = (a: any[], b: any[]): any[] =>
    a.slice(0, -1).concat([a[a.length - 1].concat(b[0])]).concat(b.slice(1));

const isNumber = /\d/;
export const isCFI = /^epubcfi\((.*)\)$/;
const escapeCFI = (str: string): string => str.replace(/[\^[\](),;=]/g, '^$&');

const wrap = (x: string): string => isCFI.test(x) ? x : `epubcfi(${x})`;
const unwrap = (x: string): string => x.match(isCFI)?.[1] ?? x;
const lift = (f: (...xs: string[]) => string) => (...xs: string[]): string =>
    `epubcfi(${f(...xs.map(x => x.match(isCFI)?.[1] ?? x))})`;

export const joinIndir = lift((...xs) => xs.join('!'));

const tokenizer = (str: string): [string, any][] => {
    const tokens: [string, any][] = [];
    let state: string | null, escape: boolean, value: string = '';
    // Fix: Ensure pushed tuples always have two elements to match the declared type.
    const push = (x: [string, any]) => (tokens.push(x), state = null, value = '');
    const cat = (x: string) => (value += x, escape = false);

    for (const char of Array.from(str.trim()).concat('')) {
        if (char === '^' && !escape) {
            escape = true;
            continue;
        }
        if (state === '!') push(['!', undefined]);
        else if (state === ',') push([',', undefined]);
        else if (state === '/' || state === ':') {
            if (isNumber.test(char)) {
                cat(char);
                continue;
            } else push([state, parseInt(value)]);
        } else if (state === '~') {
            if (isNumber.test(char) || char === '.') {
                cat(char);
                continue;
            } else push(['~', parseFloat(value)]);
        } else if (state === '@') {
            if (char === ':') {
                push(['@', parseFloat(value)]);
                state = '@';
                continue;
            }
            if (isNumber.test(char) || char === '.') {
                cat(char);
                continue;
            } else push(['@', parseFloat(value)]);
        } else if (state === '[') {
            if (char === ';' && !escape) {
                push(['[', value]);
                state = ';';
            } else if (char === ',' && !escape) {
                push(['[', value]);
                state = '[';
            } else if (char === ']' && !escape) push(['[', value]);
            else cat(char);
            continue;
        } else if (state?.startsWith(';')) {
            if (char === '=' && !escape) {
                state = `;${value}`;
                value = '';
            } else if (char === ';' && !escape) {
                push([state, value]);
                state = ';';
            } else if (char === ']' && !escape) push([state, value]);
            else cat(char);
            continue;
        }
        if (['/', ':', '~', '@', '[', '!', ','].includes(char)) state = char;
    }
    return tokens;
};

const findTokens = (tokens: [string, any][], x: string) => findIndices(tokens, ([t]) => t === x);

const parser = (tokens: [string, any][]): any[] => {
    const parts: any[] = [];
    let state: string = '';
    for (const [type, val] of tokens) {
        if (type === '/') parts.push({ index: val });
        else {
            const last = parts[parts.length - 1];
            if(!last) continue;
            if (type === ':') last.offset = val;
            else if (type === '~') last.temporal = val;
            else if (type === '@') last.spatial = (last.spatial ?? []).concat(val);
            else if (type === ';s') last.side = val;
            else if (type === '[') {
                if (state === '/' && val) last.id = val;
                else {
                    last.text = (last.text ?? []).concat(val);
                    continue;
                }
            }
        }
        state = type;
    }
    return parts;
};

const parserIndir = (tokens: [string, any][]): any[][] =>
    splitAt(tokens, findTokens(tokens, '!')).map(parser);

export const parse = (cfi: string): any => {
    const tokens = tokenizer(unwrap(cfi));
    const commas = findTokens(tokens, ',');
    if (!commas.length) return parserIndir(tokens);
    const [parent, start, end] = splitAt(tokens, commas).map(parserIndir);
    return { parent, start, end };
};

const partToString = ({ index, id, offset, temporal, spatial, text, side }: any): string => {
    const param = side ? `;s=${side}` : '';
    return `/${index}`
        + (id ? `[${escapeCFI(id)}${param}]` : '')
        + (offset != null && index % 2 ? `:${offset}` : '')
        + (temporal ? `~${temporal}` : '')
        + (spatial ? `@${spatial.join(':')}` : '')
        + (text || (!id && side) ? '['
            + (text?.map(escapeCFI)?.join(',') ?? '')
            + param + ']' : '');
};

const toInnerString = (parsed: any): string => parsed.parent
    ? [parsed.parent, parsed.start, parsed.end].map(toInnerString).join(',')
    : parsed.map((parts: any[]) => parts.map(partToString).join('')).join('!');

const toString = (parsed: any): string => wrap(toInnerString(parsed));

export const collapse = (x: string | any, toEnd?: boolean): any => {
    const parsed = typeof x === 'string' ? parse(x) : x;
    return parsed.parent ? concatArrays(parsed.parent, parsed[toEnd ? 'end' : 'start']) : parsed;
};

const buildRange = (from: string | any, to: string | any): string => {
    let fromParsed = typeof from === 'string' ? parse(from) : from;
    let toParsed = typeof to === 'string' ? parse(to) : to;
    fromParsed = collapse(fromParsed);
    toParsed = collapse(toParsed, true);
    
    const localFrom = fromParsed[fromParsed.length - 1];
    const localTo = toParsed[toParsed.length - 1];
    const localParent: any[] = [], localStart: any[] = [], localEnd: any[] = [];
    let pushToParent = true;
    const len = Math.max(localFrom.length, localTo.length);
    for (let i = 0; i < len; i++) {
        const a = localFrom[i], b = localTo[i];
        pushToParent &&= a?.index === b?.index && !a?.offset && !b?.offset;
        if (pushToParent) localParent.push(a);
        else {
            if (a) localStart.push(a);
            if (b) localEnd.push(b);
        }
    }
    const parent = fromParsed.slice(0, -1).concat([localParent]);
    return toString({ parent, start: [localStart], end: [localEnd] });
};

export const compare = (a: string | any, b: string | any): number => {
    let aParsed = typeof a === 'string' ? parse(a) : a;
    let bParsed = typeof b === 'string' ? parse(b) : b;

    if (aParsed.start || bParsed.start) {
        return compare(collapse(aParsed), collapse(bParsed))
            || compare(collapse(aParsed, true), collapse(bParsed, true));
    }

    for (let i = 0; i < Math.max(aParsed.length, bParsed.length); i++) {
        const p = aParsed[i] ?? [], q = bParsed[i] ?? [];
        const maxIndex = Math.max(p.length, q.length) - 1;
        for (let j = 0; j <= maxIndex; j++) {
            const x = p[j], y = q[j];
            if (!x) return -1;
            if (!y) return 1;
            if (x.index > y.index) return 1;
            if (x.index < y.index) return -1;
            if (j === maxIndex) {
                if (x.offset > y.offset) return 1;
                if (x.offset < y.offset) return -1;
            }
        }
    }
    return 0;
};

const isTextNode = (node: Node): boolean => node.nodeType === Node.TEXT_NODE || node.nodeType === Node.CDATA_SECTION_NODE;
const isElementNode = (node: Node): boolean => node.nodeType === Node.ELEMENT_NODE;

const getChildNodes = (node: Node, filter?: (node: Node) => number): (Node | null | Node[])[] => {
    const nodes = Array.from(node.childNodes)
        .filter(node => isTextNode(node) || isElementNode(node));
    if (!filter) return nodes;

    return nodes.map(node => {
        const accept = filter(node);
        if (accept === NodeFilter.FILTER_REJECT) return null;
        else if (accept === NodeFilter.FILTER_SKIP) return getChildNodes(node, filter);
        else return node;
    }).flat().filter(x => x);
};

const indexChildNodes = (node: Node, filter?: (node: Node) => number): any[] => {
    const nodes = getChildNodes(node, filter)
        .reduce((arr: any[], node: any) => {
            let last = arr[arr.length - 1];
            if (!last) arr.push(node);
            else if (isTextNode(node)) {
                if (Array.isArray(last)) last.push(node);
                else if (isTextNode(last)) arr[arr.length - 1] = [last, node];
                else arr.push(node);
            } else {
                if (isElementNode(last)) arr.push(null, node);
                else arr.push(node);
            }
            return arr;
        }, []);
    if (isElementNode(nodes[0])) nodes.unshift('first');
    if (isElementNode(nodes[nodes.length - 1])) nodes.push('last');
    nodes.unshift('before');
    nodes.push('after');
    return nodes;
};

const partsToNode = (node: Node | null, parts: any[], filter?: (node: Node) => number): any => {
    const { id } = parts[parts.length - 1];
    if (id && node) {
        const el = (node.ownerDocument || node as Document).getElementById(id);
        if (el) return { node: el, offset: 0 };
    }
    for (const { index } of parts) {
        const newNode = node ? indexChildNodes(node, filter)[index] : null;
        if (newNode === 'first') return { node: (node as Element).firstChild ?? node };
        if (newNode === 'last') return { node: (node as Element).lastChild ?? node };
        if (newNode === 'before') return { node, before: true };
        if (newNode === 'after') return { node, after: true };
        node = newNode;
    }
    const { offset } = parts[parts.length - 1];
    if (!Array.isArray(node)) return { node, offset };

    let sum = 0;
    for (const n of node as Text[]) {
        const length = n.nodeValue?.length || 0;
        if (sum + length >= offset) return { node: n, offset: offset - sum };
        sum += length;
    }
    // Fallback if offset is out of bounds
    return { node: node[node.length - 1], offset: node[node.length - 1].nodeValue?.length || 0 };
};

const nodeToParts = (node: Node, offset?: number | null, filter?: (node: Node) => number): any[] => {
    const { parentNode } = node;
    if (!parentNode) return [];

    const indexed = indexChildNodes(parentNode, filter);
    const index = indexed.findIndex(x => Array.isArray(x) ? x.some(x_ => x_ === node) : x === node);

    if (offset != null) {
        const chunk = indexed[index];
        if (Array.isArray(chunk)) {
            let sum = 0;
            for (const x of chunk as Text[]) {
                if (x === node) {
                    sum += offset;
                    break;
                } else sum += x.nodeValue?.length || 0;
            }
            offset = sum;
        }
    }
    const id = (node as Element).id;
    const part = { id, index, offset };
    
    const parentParts = (parentNode !== (node.ownerDocument?.documentElement))
        ? nodeToParts(parentNode, null, filter)
        : [];
        
    return parentParts.concat(part).filter(x => x.index !== -1);
};


export const fromRange = (range: Range, filter?: (node: Node) => number): string => {
    const { startContainer, startOffset, endContainer, endOffset } = range;
    const start = nodeToParts(startContainer, startOffset, filter);
    if (range.collapsed) return toString([start]);
    const end = nodeToParts(endContainer, endOffset, filter);
    return buildRange([start], [end]);
};

export const toRange = (doc: Document, parts: any, filter?: (node: Node) => number): Range => {
    const startParts = collapse(parts);
    const endParts = collapse(parts, true);

    const root = doc.documentElement;
    const start = partsToNode(root, startParts[0], filter);
    const end = partsToNode(root, endParts[0], filter);

    const range = doc.createRange();

    if (start.before) range.setStartBefore(start.node);
    else if (start.after) range.setStartAfter(start.node);
    else range.setStart(start.node, start.offset);

    if (end.before) range.setEndBefore(end.node);
    else if (end.after) range.setEndAfter(end.node);
    else range.setEnd(end.node, end.offset);
    return range;
};

export const fromElements = (elements: Element[]): string[] => {
    if (!elements || elements.length === 0) return [];
    const results: string[] = [];
    const { parentNode } = elements[0];
    if (!parentNode) return [];
    
    const parts = nodeToParts(parentNode);
    for (const [index, node] of indexChildNodes(parentNode).entries()) {
        const el = elements[results.length];
        if (node === el) {
            results.push(toString([parts.concat({ id: el.id, index })]));
        }
    }
    return results;
};

export const toElement = (doc: Document, parts: any): Node | null =>
    partsToNode(doc.documentElement, collapse(parts)).node;


export const fake = {
    fromIndex: (index: number) => wrap(`/6/${(index + 1) * 2}`),
    // Fix: Replace .at() with bracket notation for broader JS compatibility.
    toIndex: (parts: any[] | null): number => (parts?.[parts.length - 1]?.index ?? 0) / 2 - 1,
};

export const fromCalibrePos = (pos: string): string => {
    const [parts] = parse(pos);
    const item = parts.shift();
    parts.shift();
    return toString([[{ index: 6 }, item], parts]);
};

export const fromCalibreHighlight = ({ spine_index, end_cfi, start_cfi }: { spine_index: number; start_cfi: string; end_cfi: string }): string => {
    const pre = fake.fromIndex(spine_index) + '!';
    return buildRange(pre + start_cfi.slice(2), pre + end_cfi.slice(2));
};