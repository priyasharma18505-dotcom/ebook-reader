

import type { Book, Section, TOCItem } from '../types';

const normalizeWhitespace = (str: string | null | undefined): string => {
    if (!str) return '';
    return str
        .replace(/[\t\n\f\r ]+/g, ' ')
        .replace(/^[\t\n\f\r ]+/, '')
        .replace(/[\t\n\f\r ]+$/, '');
};

const getElementText = (el: Element | null): string => normalizeWhitespace(el?.textContent);

const NS = {
    XLINK: 'http://www.w3.org/1999/xlink',
    EPUB: 'http://www.idpf.org/2007/ops',
    // Fix: Add missing XHTML namespace.
    XHTML: 'http://www.w3.org/1999/xhtml',
};

const MIME = {
    XML: 'application/xml',
    XHTML: 'application/xhtml+xml',
};

type ConverterDef = { [key: string]: string | [string, any, string[]?] };

const STYLE: ConverterDef = {
    'strong': ['strong', 'self'],
    'emphasis': ['em', 'self'],
    'style': ['span', 'self'],
    'a': 'anchor',
    'strikethrough': ['s', 'self'],
    'sub': ['sub', 'self'],
    'sup': ['sup', 'self'],
    'code': ['code', 'self'],
};

const TABLE: ConverterDef = {
    'tr': ['tr', {
        'th': ['th', STYLE, ['colspan', 'rowspan', 'align', 'valign']],
        'td': ['td', STYLE, ['colspan', 'rowspan', 'align', 'valign']],
    }, ['align']],
};

const POEM: ConverterDef = {
    // Fix: Ensure tuple has correct number of elements.
    'epigraph': ['blockquote', {}],
    'subtitle': ['h2', STYLE],
    'text-author': ['p', STYLE],
    'date': ['p', STYLE],
    'stanza': 'stanza',
};

const SECTION: ConverterDef = {
    'title': ['header', {
        'p': ['h1', STYLE],
        'empty-line': ['br', undefined],
    }],
    'epigraph': ['blockquote', 'self'],
    'image': 'image',
    // Fix: Ensure tuple has correct number of elements.
    'annotation': ['aside', undefined],
    'section': ['section', 'self'],
    'p': ['p', STYLE],
    'poem': ['blockquote', POEM],
    'subtitle': ['h2', STYLE],
    'cite': ['blockquote', 'self'],
    // Fix: Ensure tuple has correct number of elements.
    'empty-line': ['br', undefined],
    'table': ['table', TABLE],
    'text-author': ['p', STYLE],
};
(POEM['epigraph'] as any[]).push(SECTION);

const BODY: ConverterDef = {
    'image': 'image',
    'title': ['section', {
        'p': ['h1', STYLE],
        'empty-line': ['br', undefined],
    }],
    'epigraph': ['section', SECTION],
    'section': ['section', SECTION],
};

class FB2Converter {
    private fb2: Document;
    private doc: Document;
    private bins: Map<string, Element>;

    constructor(fb2: Document) {
        this.fb2 = fb2;
        this.doc = document.implementation.createDocument(NS.XHTML, 'html');
        this.bins = new Map(Array.from(this.fb2.getElementsByTagName('binary'),
            el => [el.id, el]));
    }

    private getImageSrc(el: Element): string {
        const href = el.getAttributeNS(NS.XLINK, 'href');
        if (!href) return 'data:,';
        const [, id] = href.split('#');
        if (!id) return href;
        const bin = this.bins.get(id);
        return bin
            ? `data:${bin.getAttribute('content-type')};base64,${bin.textContent}`
            : href;
    }

    private image(node: Element): HTMLElement {
        const el = this.doc.createElement('img');
        el.alt = node.getAttribute('alt') || '';
        el.title = node.getAttribute('title') || '';
        el.setAttribute('src', this.getImageSrc(node));
        return el;
    }

    private anchor(node: Element): HTMLElement {
        const el = this.convert(node, { 'a': ['a', STYLE] }) as HTMLAnchorElement;
        el.setAttribute('href', node.getAttributeNS(NS.XLINK, 'href') || '#');
        if (node.getAttribute('type') === 'note')
            el.setAttributeNS(NS.EPUB, 'epub:type', 'noteref');
        return el;
    }
    
    private stanza(node: Element): HTMLElement {
        const p = this.doc.createElement('p');
        p.classList.add('stanza');

        for (const child of Array.from(node.children)) {
             if (child.nodeName === 'title' || child.nodeName === 'subtitle') {
                const header = this.convert(child, {
                    'title': ['strong', STYLE],
                    'subtitle': ['em', STYLE],
                });
                if(header) p.appendChild(header);
            } else if (child.nodeName === 'v') {
                p.appendChild(this.doc.createTextNode(child.textContent || ''));
                p.appendChild(this.doc.createElement('br'));
            }
        }
        return p;
    }

    convert(node: Node, def: ConverterDef): HTMLElement | Text | null {
        if (node.nodeType === Node.TEXT_NODE) return this.doc.createTextNode(node.textContent || '');
        if (node.nodeType !== Node.ELEMENT_NODE) return null;

        const elementNode = node as Element;
        const d = def[elementNode.nodeName];
        if (!d) return null;
        if (typeof d === 'string') {
            return (this as any)[d](elementNode);
        }

        const [name, opts, attrs] = d;
        const el = this.doc.createElement(name);

        if (elementNode.id) el.id = elementNode.id;
        el.classList.add(elementNode.nodeName);

        if (Array.isArray(attrs)) {
            for (const attr of attrs) {
                const value = elementNode.getAttribute(attr);
                if (value) el.setAttribute(attr, value);
            }
        }

        const childDef = opts === 'self' ? def : opts;
        let child = elementNode.firstChild;
        while (child) {
            const childEl = this.convert(child, childDef);
            if (childEl) el.append(childEl);
            child = child.nextSibling;
        }
        return el;
    }
}

const parseXML = async (blob: Blob): Promise<Document> => {
    const buffer = await blob.arrayBuffer();
    const parser = new DOMParser();
    let firstError: string | undefined;

    try {
        let str = new TextDecoder('utf-8', { fatal: true }).decode(buffer);
        if (str.codePointAt(0) === 0xFEFF) str = str.substring(1);
        
        // Fix: Cast string to DOMParserSupportedType.
        const doc = parser.parseFromString(str, MIME.XML as DOMParserSupportedType);
        if (!doc.querySelector('parsererror')) {
            // Fix: Cast doc to any to access non-standard xmlEncoding property.
            const encoding = (doc as any).xmlEncoding || str.match(/^<\?xml\s+version\s*=\s*["']1.\d+"\s+encoding\s*=\s*["']([A-Za-z0-9._-]*)["']/)?.[1];
            if (encoding && encoding.toLowerCase() !== 'utf-8') {
                try {
                    const specificDecoder = new TextDecoder(encoding, { fatal: true });
                    str = specificDecoder.decode(buffer);
                    if (str.codePointAt(0) === 0xFEFF) str = str.substring(1);
                    // Fix: Cast string to DOMParserSupportedType.
                    const reParsedDoc = parser.parseFromString(str, MIME.XML as DOMParserSupportedType);
                    if (!reParsedDoc.querySelector('parsererror')) {
                        return reParsedDoc;
                    }
                } catch (e) {
                    // Fallback to UTF-8 parsed doc
                }
            }
            return doc;
        }
        firstError = doc.querySelector('parsererror')?.textContent || 'Unknown parsing error';
    } catch (e: any) {
        firstError = e.message;
    }

    try {
        const str = new TextDecoder('windows-1251').decode(buffer);
        // Fix: Cast string to DOMParserSupportedType.
        const doc = parser.parseFromString(str, MIME.XML as DOMParserSupportedType);
        if (!doc.querySelector('parsererror')) return doc;
    } catch (e) {}
    
    throw new Error(`FB2 parsing error: ${firstError}`);
};

let styleURL: string | null = null;
const getStyleURL = (): string => {
    if (!styleURL) {
        styleURL = URL.createObjectURL(new Blob([`
@namespace epub "http://www.idpf.org/2007/ops";
body > img, section > img { display: block; margin: auto; max-width: 100%; height: auto; }
.title h1 { text-align: center; }
body > section > .title, body.notesBodyType > .title { margin: 3em 0; }
body.notesBodyType > section .title h1 { text-align: start; }
body.notesBodyType > section .title { margin: 1em 0; }
p { text-indent: 1.5em; margin: 0; }
p:first-of-type { text-indent: 0; }
div > p:first-child { text-indent: 0; }
.poem, .cite { text-indent: 0; margin: 1em 0; padding: 0 2em; }
.stanza { margin: 1em 0; text-indent:0; }
.text-author, .date { text-align: right; font-style: italic; }
.text-author:before { content: "— "; }
table { border-collapse: collapse; margin: 1em auto; }
td, th { padding: .25em; border: 1px solid #ccc; }
a[epub|type~="noteref"] { font-size: .75em; vertical-align: super; line-height: 1; }
body:not(.notesBodyType) > .title, body:not(.notesBodyType) > .epigraph { margin: 3em 0; }
`], { type: 'text/css' }));
    }
    return styleURL;
};

const template = (html: string) => `<?xml version="1.0" encoding="utf-8"?>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops">
    <head><link href="${getStyleURL()}" rel="stylesheet" type="text/css"/></head>
    <body>${html}</body>
</html>`;

const dataID = 'data-foliate-id';

export const makeFB2 = async (blob: Blob): Promise<Book> => {
    const doc = await parseXML(blob);
    const converter = new FB2Converter(doc);

    const $ = (selector: string) => doc.querySelector(selector);
    const $$ = (selector: string) => Array.from(doc.querySelectorAll(selector));

    const getPerson = (el: Element) => {
        const nick = getElementText(el.querySelector('nickname'));
        if (nick) return { name: nick };
        const first = getElementText(el.querySelector('first-name'));
        const middle = getElementText(el.querySelector('middle-name'));
        const last = getElementText(el.querySelector('last-name'));
        return { name: [first, middle, last].filter(Boolean).join(' ') };
    };

    const getDate = (el: Element | null) => el?.getAttribute('value') || getElementText(el);

    const annotation = $('title-info > annotation');
    const book: Book = {
        metadata: {
            title: getElementText($('title-info > book-title')),
            identifier: getElementText($('document-info > id')),
            language: getElementText($('title-info > lang')),
            author: $$('title-info > author').map(getPerson),
            translator: $$('title-info > translator').map(getPerson),
            publisher: getElementText($('publish-info > publisher')),
            published: getDate($('title-info > date')),
            modified: getDate($('document-info > date')),
            description: annotation ? (converter.convert(annotation, { annotation: ['div', SECTION] }) as HTMLElement)?.innerHTML : undefined,
            subject: $$('title-info > genre').map(getElementText),
        },
        sections: [],
        toc: [],
    };

    const coverpageImage = $('coverpage image');
    if (coverpageImage) {
        book.getCover = async () => {
             const src = (converter as any).getImageSrc(coverpageImage);
             if(!src || src === 'data:,') return null;
             const res = await fetch(src);
             return res.blob();
        }
    } else {
        book.getCover = () => Promise.resolve(null);
    }
    
    const bodyData = $$('body').map(body => {
        const converted = converter.convert(body, { body: ['body', BODY] }) as HTMLElement;
        return {
            sections: Array.from(converted.children).map(el => ({
                el,
                ids: [el.id, ...Array.from(el.querySelectorAll('[id]'), e => e.id)].filter(Boolean)
            })),
            body: converted
        };
    });

    const urls: string[] = [];
    const idMap = new Map<string, number>();

    const sectionData = bodyData[0].sections.map(({ el, ids }) => {
        const titles = Array.from(el.querySelectorAll(':scope > section > .title'), (titleEl, index) => {
            titleEl.setAttribute(dataID, String(index));
            return { title: getElementText(titleEl), index };
        });
        return { ids, titles, el, linear: 'yes' };
    }).concat(bodyData.slice(1).map(({ sections, body }) => {
        const ids = sections.flatMap(s => s.ids);
        body.classList.add('notesBodyType');
        return { ids, titles: [], el: body, linear: 'no' };
    }));

    book.sections = sectionData.map(({ ids, el, linear }, index) => {
        const str = template(el.outerHTML);
        const sectionBlob = new Blob([str], { type: MIME.XHTML });
        const url = URL.createObjectURL(sectionBlob);
        urls.push(url);
        
        for (const id of ids) {
            if (id) idMap.set(id, index);
        }

        return {
            id: index,
            load: () => Promise.resolve(url),
            // Fix: Wrap return value in a resolved promise to match Section interface.
            createDocument: () => Promise.resolve(new DOMParser().parseFromString(str, MIME.XHTML as DOMParserSupportedType)),
            size: sectionBlob.size,
            linear,
        };
    });

    book.toc = sectionData.map(({ el, titles }, index) => {
        const h1 = el.querySelector('h1');
        const p = el.querySelector('p');
        const label = normalizeWhitespace(h1?.textContent || p?.textContent || 'Unnamed Section');
        const href = String(index);

        return {
            label,
            href,
            subitems: titles?.length ? titles.map(({ title, index: subIndex }) => ({
                label: title,
                href: `${href}#${subIndex}`,
            })) : undefined,
        };
    // Fix: Remove problematic type predicate.
    }).filter((item) => !!item);

    book.resolveHref = href => {
        const [idPart, fragmentPart] = href.split('#');
        const index = idMap.get(idPart) ?? Number(idPart);

        if (isNaN(index)) return null;

        const anchor = (doc: Document) => {
             if (fragmentPart) {
                 return doc.querySelector(`[${dataID}="${fragmentPart}"]`) || doc.getElementById(fragmentPart);
             }
             return doc.body;
        };
        return { index, anchor };
    };

    book.splitTOCHref = (href: string) => href?.split('#') ?? [];
    book.getTOCFragment = (doc, id) => doc.querySelector(`[${dataID}="${id}"]`);

    book.destroy = () => {
        for (const url of urls) URL.revokeObjectURL(url);
        if (styleURL) {
            URL.revokeObjectURL(styleURL);
            styleURL = null;
        }
    };

    return book;
};
