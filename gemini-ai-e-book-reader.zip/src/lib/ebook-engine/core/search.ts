import { textWalker } from '../utils/text-walker';

// Fix: Add declarations for the experimental Intl.Segmenter and missing Intl.Collator API.
declare namespace Intl {
    interface SegmenterOptions {
        localeMatcher?: "lookup" | "best fit";
        granularity?: "grapheme" | "word" | "sentence";
    }
    interface Segment {
        segment: string;
        index: number;
        isWordLike?: boolean;
    }
    class Segmenter {
        constructor(locales?: string | string[], options?: SegmenterOptions);
        segment(input: string): Iterable<Segment>;
    }
    // Fix: Add declaration for Intl.Collator to resolve TS errors.
    interface CollatorOptions {
        usage?: "sort" | "search";
        localeMatcher?: "lookup" | "best fit";
        numeric?: boolean;
        caseFirst?: "upper" | "lower" | "false";
        sensitivity?: "base" | "accent" | "case" | "variant";
        ignorePunctuation?: boolean;
    }
    class Collator {
        constructor(locales?: string | string[], options?: CollatorOptions);
        compare(a: string, b: string): number;
        resolvedOptions(): any;
    }
}


// length for context in excerpts
const CONTEXT_LENGTH = 50;

const normalizeWhitespace = (str: string) => str.replace(/\s+/g, ' ');

interface RangeOffsets {
    startIndex: number;
    startOffset: number;
    endIndex: number;
    endOffset: number;
}

export interface Excerpt {
    pre: string;
    match: string;
    post: string;
}

export interface SearchResult {
    range: Range;
    excerpt: Excerpt;
}

interface InternalSearchResult {
    range: RangeOffsets;
    excerpt: Excerpt;
}

const makeExcerpt = (strs: string[], { startIndex, startOffset, endIndex, endOffset }: RangeOffsets): Excerpt => {
    const start = strs[startIndex];
    const end = strs[endIndex];
    const match = start === end
        ? start.slice(startOffset, endOffset)
        : start.slice(startOffset)
        + strs.slice(startIndex + 1, endIndex).join('')
        + end.slice(0, endOffset);

    const trimmedStart = normalizeWhitespace(start.slice(0, startOffset)).trimStart();
    const trimmedEnd = normalizeWhitespace(end.slice(endOffset)).trimEnd();
    const ellipsisPre = trimmedStart.length < CONTEXT_LENGTH ? '' : '…';
    const ellipsisPost = trimmedEnd.length < CONTEXT_LENGTH ? '' : '…';
    const pre = `${ellipsisPre}${trimmedStart.slice(-CONTEXT_LENGTH)}`;
    const post = `${trimmedEnd.slice(0, CONTEXT_LENGTH)}${ellipsisPost}`;
    return { pre, match, post };
};

export interface SearchOptions {
    locales?: string | string[];
    sensitivity?: 'base' | 'accent' | 'case' | 'variant';
    granularity?: 'grapheme' | 'word' | 'sentence';
}

function* simpleSearch(strs: string[], query: string, options: SearchOptions = {}): Generator<InternalSearchResult> {
    const { locales = 'en', sensitivity } = options;
    const matchCase = sensitivity === 'variant';
    const haystack = strs.join('');
    const lowerHaystack = matchCase ? haystack : haystack.toLocaleLowerCase(locales);
    const needle = matchCase ? query : query.toLocaleLowerCase(locales);
    const needleLength = needle.length;
    let index = -1;
    let strIndex = -1;
    let sum = 0;
    do {
        index = lowerHaystack.indexOf(needle, index + 1);
        if (index > -1) {
            while (sum <= index) sum += strs[++strIndex]?.length || 0;
            const startIndex = strIndex;
            const startOffset = index - (sum - (strs[strIndex]?.length || 0));
            const end = index + needleLength;
            while (sum <= end) sum += strs[++strIndex]?.length || 0;
            const endIndex = strIndex;
            const endOffset = end - (sum - (strs[strIndex]?.length || 0));
            const range = { startIndex, startOffset, endIndex, endOffset };
            yield { range, excerpt: makeExcerpt(strs, range) };
        }
    } while (index > -1);
}

function* segmenterSearch(strs: string[], query: string, options: SearchOptions = {}): Generator<InternalSearchResult> {
    const { locales = 'en', granularity = 'word', sensitivity = 'base' } = options;
    let segmenter: Intl.Segmenter, collator: Intl.Collator;
    try {
        segmenter = new Intl.Segmenter(locales, { usage: 'search', granularity } as any);
        collator = new Intl.Collator(locales, { sensitivity });
    } catch (e) {
        console.warn(e);
        segmenter = new Intl.Segmenter('en', { usage: 'search', granularity } as any);
        collator = new Intl.Collator('en', { sensitivity });
    }
    const queryLength = Array.from(segmenter.segment(query)).length;

    const substrArr: (Intl.Segment & { strIndex: number })[] = [];
    let strIndex = 0;
    let segments = segmenter.segment(strs[strIndex])[Symbol.iterator]();

    main: while (strIndex < strs.length) {
        while (substrArr.length < queryLength) {
            const { done, value } = segments.next();
            if (done) {
                strIndex++;
                if (strIndex < strs.length) {
                    segments = segmenter.segment(strs[strIndex])[Symbol.iterator]();
                    continue;
                } else break main;
            }
            const { index, segment } = value;
            if (!/[^\p{Format}]/u.test(segment)) continue;
            if (/\s/u.test(segment)) {
                if (!/\s/u.test(substrArr[substrArr.length - 1]?.segment))
                    substrArr.push({ strIndex, index, segment: ' ', isWordLike: false });
                continue;
            }
            substrArr.push({ ...value, strIndex });
        }
        const substr = substrArr.map(x => x.segment).join('');
        if (collator.compare(query, substr) === 0) {
            const endIndex = strIndex;
            const lastSeg = substrArr[substrArr.length - 1];
            const endOffset = lastSeg.index + lastSeg.segment.length;
            const startIndex = substrArr[0].strIndex;
            const startOffset = substrArr[0].index;
            const range = { startIndex, startOffset, endIndex, endOffset };
            yield { range, excerpt: makeExcerpt(strs, range) };
        }
        substrArr.shift();
    }
}

export const search = (strs: string[], query: string, options: SearchOptions): Generator<InternalSearchResult> => {
    const { granularity = 'grapheme', sensitivity = 'base' } = options;
    if (!Intl?.Segmenter || (granularity === 'grapheme' && (sensitivity === 'variant' || sensitivity === 'accent')))
        return simpleSearch(strs, query, options);
    return segmenterSearch(strs, query, options);
}

export interface MatcherOptions {
    defaultLocale?: string;
    matchCase?: boolean;
    matchDiacritics?: boolean;
    matchWholeWords?: boolean;
    acceptNode?: (node: Node) => number;
}

type TextWalker = typeof textWalker;

export const searchMatcher = (textWalkerFunc: TextWalker, opts: MatcherOptions) => {
    const { defaultLocale, matchCase, matchDiacritics, matchWholeWords, acceptNode } = opts;
    return function* (doc: Document, query: string): Generator<SearchResult> {
        const iter = textWalkerFunc(doc, function* (strs, makeRange) {
            for (const result of search(strs, query, {
                locales: doc.body?.lang || doc.documentElement?.lang || defaultLocale || 'en',
                granularity: matchWholeWords ? 'word' : 'grapheme',
                sensitivity: matchDiacritics && matchCase ? 'variant'
                    : matchDiacritics && !matchCase ? 'accent'
                        : !matchDiacritics && matchCase ? 'case'
                            : 'base',
            })) {
                const { startIndex, startOffset, endIndex, endOffset } = result.range;
                (result as any).range = makeRange(startIndex, startOffset, endIndex, endOffset);
                yield result;
            }
        // Fix: Cast the generator function to any to resolve the complex type incompatibility.
        } as any, acceptNode);

        for (const result of iter) {
            // Fix: Correctly cast the result from the generic iterator.
            yield result as unknown as SearchResult;
        }
    }
}