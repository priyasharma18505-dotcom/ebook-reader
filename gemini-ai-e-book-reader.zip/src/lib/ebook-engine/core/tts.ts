

import { textWalker as defaultTextWalker } from '../utils/text-walker';

// Fix: Add declaration for the experimental Intl.Segmenter API.
declare namespace Intl {
    interface SegmenterOptions {
        localeMatcher?: "lookup" | "best fit";
        granularity?: "grapheme" | "word" | "sentence";
    }
    interface Segment {
        segment: string;
        index: number;
        isWordLike?: boolean;
    }
    class Segmenter {
        constructor(locales?: string | string[], options?: SegmenterOptions);
        segment(input: string): Iterable<Segment>;
    }
}

const NS = {
    XML: 'http://www.w3.org/XML/1998/namespace',
    SSML: 'http://www.w3.org/2001/10/synthesis',
};

const blockTags = new Set([
    'article', 'aside', 'audio', 'blockquote', 'caption',
    'details', 'dialog', 'div', 'dl', 'dt', 'dd',
    'figure', 'footer', 'form', 'figcaption',
    'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'header', 'hgroup', 'hr', 'li',
    'main', 'math', 'nav', 'ol', 'p', 'pre', 'section', 'tr',
]);

const getLang = (el: Element | null): string | null => {
    if (!el) return null;
    // Fix: Cast to HTMLElement to access the 'lang' property.
    const x = (el as HTMLElement).lang || el.getAttributeNS?.(NS.XML, 'lang');
    return x ? x : getLang(el.parentElement);
};

const getAlphabet = (el: Element | null): string | null => {
    if (!el) return null;
    const x = el.getAttributeNS?.(NS.SSML, 'alphabet');
    return x ? x : getAlphabet(el.parentElement);
};

type MakeRangeFunc = (startIndex: number, startOffset: number, endIndex: number, endOffset: number) => Range;

const getSegmenter = (lang: string = 'en', granularity: 'grapheme' | 'word' | 'sentence' = 'word') => {
    const segmenter = new Intl.Segmenter(lang, { granularity });
    const granularityIsWord = granularity === 'word';

    return function* (strs: string[], makeRange: MakeRangeFunc): Generator<[string, Range]> {
        const str = strs.join('');
        let name = 0;
        let strIndex = -1;
        let sum = 0;
        for (const { index, segment, isWordLike } of segmenter.segment(str)) {
            if (granularityIsWord && !isWordLike) continue;
            while (sum <= index) sum += strs[++strIndex]?.length || 0;
            const startIndex = strIndex;
            const startOffset = index - (sum - (strs[strIndex]?.length || 0));
            const end = index + segment.length - 1;
            if (end < str.length) {
                while (sum <= end) sum += strs[++strIndex]?.length || 0;
            }
            const endIndex = strIndex;
            const endOffset = end - (sum - (strs[strIndex]?.length || 0)) + 1;
            yield [(name++).toString(), makeRange(startIndex, startOffset, endIndex, endOffset)];
        }
    };
};

const fragmentToSSML = (fragment: DocumentFragment, inherited: { lang: string | null; alphabet: string | null }): Document => {
    const ssml = document.implementation.createDocument(NS.SSML, 'speak', null);
    const { lang } = inherited;
    if (lang) ssml.documentElement.setAttributeNS(NS.XML, 'lang', lang);

    const convert = (node: Node | null, parent: Element, inheritedAlphabet: string | null): Element | Text | CDATASection | Comment | null => {
        if (!node) return null;
        if (node.nodeType === Node.TEXT_NODE) return ssml.createTextNode(node.textContent || '');
        if (node.nodeType === Node.CDATA_SECTION_NODE) return ssml.createCDATASection(node.textContent || '');
        if (node.nodeType !== Node.ELEMENT_NODE) return null;

        let el: Element | undefined;
        const elementNode = node as Element;
        const nodeName = elementNode.nodeName.toLowerCase();

        if (nodeName === 'foliate-mark') {
            el = ssml.createElementNS(NS.SSML, 'mark');
            // Fix: Cast to HTMLElement to access 'dataset'.
            el.setAttribute('name', (elementNode as HTMLElement).dataset.name || '');
        } else if (nodeName === 'br') {
            el = ssml.createElementNS(NS.SSML, 'break');
        } else if (nodeName === 'em' || nodeName === 'strong') {
            el = ssml.createElementNS(NS.SSML, 'emphasis');
        }

        // Fix: Cast to HTMLElement to access 'lang'.
        const currentLang = (elementNode as HTMLElement).lang || elementNode.getAttributeNS(NS.XML, 'lang');
        if (currentLang) {
            if (!el) el = ssml.createElementNS(NS.SSML, 'lang');
            el.setAttributeNS(NS.XML, 'lang', currentLang);
        }

        const alphabet = elementNode.getAttributeNS(NS.SSML, 'alphabet') || inheritedAlphabet;
        if (!el) {
            const ph = elementNode.getAttributeNS(NS.SSML, 'ph');
            if (ph) {
                el = ssml.createElementNS(NS.SSML, 'phoneme');
                if (alphabet) el.setAttribute('alphabet', alphabet);
                el.setAttribute('ph', ph);
            }
        }

        if (!el) el = parent;

        let child = elementNode.firstChild;
        while (child) {
            const childEl = convert(child, el, alphabet);
            if (childEl && el !== childEl) el.append(childEl);
            child = child.nextSibling;
        }
        return el;
    };

    convert(fragment.firstChild, ssml.documentElement, inherited.alphabet);
    return ssml;
};

const getFragmentWithMarks = (range: Range, textWalker: typeof defaultTextWalker, granularity: 'grapheme' | 'word' | 'sentence') => {
    const lang = getLang(range.commonAncestorContainer as Element);
    const alphabet = getAlphabet(range.commonAncestorContainer as Element);

    const segmenter = getSegmenter(lang || undefined, granularity);
    const fragment = range.cloneContents();

    const entries = [...textWalker(range, segmenter)];
    const fragmentEntries = [...textWalker(fragment, segmenter)];

    for (const [name, range] of fragmentEntries) {
        const mark = document.createElement('foliate-mark');
        mark.dataset.name = name;
        range.insertNode(mark);
    }
    const ssml = fragmentToSSML(fragment, { lang, alphabet });
    return { entries, ssml };
};

const rangeIsEmpty = (range: Range) => !(range.toString().trim());

function* getBlocks(doc: Document): Generator<Range> {
    let last: Range | undefined;
    const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_ELEMENT);
    for (let node = walker.nextNode() as Element; node; node = walker.nextNode() as Element) {
        const name = node.tagName.toLowerCase();
        if (blockTags.has(name)) {
            if (last) {
                last.setEndBefore(node);
                if (!rangeIsEmpty(last)) yield last;
            }
            last = doc.createRange();
            last.setStart(node, 0);
        }
    }
    if (!last) {
        last = doc.createRange();
        last.setStart(doc.body.firstChild ?? doc.body, 0);
    }
    last.setEndAfter(doc.body.lastChild ?? doc.body);
    if (!rangeIsEmpty(last)) yield last;
}

type TTSResult = [Document, Range];

class ListIterator {
    #arr: TTSResult[] = [];
    #iter: Generator<Range>;
    #index = -1;
    #f: (range: Range) => TTSResult;

    constructor(iter: Generator<Range>, f: (range: Range) => TTSResult) {
        this.#iter = iter;
        this.#f = f;
    }

    current(): TTSResult | undefined {
        if (this.#arr[this.#index]) return this.#arr[this.#index];
    }

    first(): TTSResult | undefined {
        const newIndex = 0;
        if (this.#arr[newIndex]) {
            this.#index = newIndex;
            return this.#arr[newIndex];
        }
        return this.next(); // Start from the beginning
    }

    prev(): TTSResult | undefined {
        const newIndex = this.#index - 1;
        if (this.#arr[newIndex]) {
            this.#index = newIndex;
            return this.#arr[newIndex];
        }
    }

    next(): TTSResult | undefined {
        const newIndex = this.#index + 1;
        if (this.#arr[newIndex]) {
            this.#index = newIndex;
            return this.#arr[newIndex];
        }
        while (true) {
            const { done, value } = this.#iter.next();
            if (done) break;
            this.#arr.push(this.#f(value));
            if (this.#arr[newIndex]) {
                this.#index = newIndex;
                return this.#arr[newIndex];
            }
        }
    }
    
    find(f: (range: Range) => boolean): TTSResult | undefined {
        const index = this.#arr.findIndex(([, range]) => f(range));
        if (index > -1) {
            this.#index = index;
            return this.#arr[index];
        }
        while (true) {
            const { done, value } = this.#iter.next();
            if (done) break;
            const result = this.#f(value);
            this.#arr.push(result);
            if (f(result[1])) {
                this.#index = this.#arr.length - 1;
                return result;
            }
        }
    }
}

export class TTS {
    public doc: Document;
    private highlight: (range: Range) => void;
    #list: ListIterator;
    #ranges: Map<string, Range> = new Map();
    #lastMark: string | null = null;
    #serializer = new XMLSerializer();

    constructor(
        doc: Document,
        textWalker: typeof defaultTextWalker,
        highlight: (range: Range) => void,
        granularity: 'grapheme' | 'word' | 'sentence'
    ) {
        this.doc = doc;
        this.highlight = highlight;
        this.#list = new ListIterator(getBlocks(doc), range => {
            const { entries, ssml } = getFragmentWithMarks(range, textWalker, granularity);
            this.#ranges = new Map(entries);
            return [ssml, range];
        });
    }

    #getMarkElement(doc: Document, mark: string | null): Element | null {
        if (!mark) return null;
        return doc.querySelector(`mark[name="${CSS.escape(mark)}"`);
    }

    #speak(doc: Document | undefined, getNode?: (ssml: Document) => Element | null): string | undefined {
        if (!doc) return;
        if (!getNode) return this.#serializer.serializeToString(doc);
        
        const ssml = document.implementation.createDocument(NS.SSML, 'speak', null);
        ssml.replaceChild(ssml.importNode(doc.documentElement, true), ssml.documentElement);
        
        let node = getNode(ssml)?.previousSibling;
        while (node) {
            const next = node.previousSibling ?? node.parentNode?.previousSibling;
            node.parentNode?.removeChild(node);
            node = next;
        }
        return this.#serializer.serializeToString(ssml);
    }

    start(): [string, Range] | [] {
        this.#lastMark = null;
        const [doc, range] = this.#list.first() ?? [];
        if (!doc) return this.next() || [];
        const ssml = this.#speak(doc, ssmlDoc => this.#getMarkElement(ssmlDoc, this.#lastMark));
        return ssml ? [ssml, range] : [];
    }

    resume(): [string, Range] | [] {
        const [doc, range] = this.#list.current() ?? [];
        if (!doc) return this.next() || [];
        const ssml = this.#speak(doc, ssmlDoc => this.#getMarkElement(ssmlDoc, this.#lastMark));
        return ssml ? [ssml, range] : [];
    }

    prev(paused?: boolean): [string, Range] | undefined {
        this.#lastMark = null;
        const [doc, range] = this.#list.prev() ?? [];
        if (!doc) return;
        if (paused && range) this.highlight(range.cloneRange());
        const ssml = this.#speak(doc);
        return ssml ? [ssml, range] : undefined;
    }

    next(paused?: boolean): [string, Range] | undefined {
        this.#lastMark = null;
        const [doc, range] = this.#list.next() ?? [];
        if (!doc) return;
        if (paused && range) this.highlight(range.cloneRange());
        const ssml = this.#speak(doc);
        return ssml ? [ssml, range] : undefined;
    }

    from(range: Range): string | undefined {
        this.#lastMark = null;
        const [doc] = this.#list.find(r => range.compareBoundaryPoints(Range.END_TO_START, r) <= 0) ?? [];
        if (!doc) return;
        
        let mark: string | undefined;
        for (const [name, r] of this.#ranges.entries()) {
            if (range.compareBoundaryPoints(Range.START_TO_START, r) <= 0) {
                mark = name;
                break;
            }
        }
        return this.#speak(doc, ssml => this.#getMarkElement(ssml, mark || null));
    }

    setMark(mark: string): void {
        const range = this.#ranges.get(mark);
        if (range) {
            this.#lastMark = mark;
            this.highlight(range.cloneRange());
        }
    }
}