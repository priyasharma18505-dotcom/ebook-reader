
import type { TOCItem, Section } from '../types';

// assign a unique ID for each TOC item
const assignIDs = (toc: TOCItem[]): TOCItem[] => {
    let id = 0;
    const assignID = (item: TOCItem) => {
        item.id = id++;
        if (item.subitems) {
            for (const subitem of item.subitems) {
                assignID(subitem);
            }
        }
    };
    for (const item of toc) {
        assignID(item);
    }
    return toc;
};

const flatten = (items: TOCItem[]): TOCItem[] => {
    return items
        .map(item => (item.subitems?.length ? [item, ...flatten(item.subitems)] : [item]))
        .flat();
};

interface GroupedTOCItem {
    fragment: string | number | undefined;
    item: TOCItem;
}

interface GroupedTOC {
    prev?: TOCItem;
    items: GroupedTOCItem[];
}

export class TOCProgress {
    private ids?: (string | number)[];
    private map?: Map<string | number, GroupedTOC | undefined>;
    private getFragment?: (doc: Document, id: any) => HTMLElement | null;

    async init({ toc, ids, splitHref, getFragment }: {
        toc: TOCItem[];
        ids: (string | number)[];
        splitHref: (href: string) => (string | number)[];
        getFragment: (doc: Document, id: any) => HTMLElement | null;
    }): Promise<void> {
        assignIDs(toc);
        const items = flatten(toc);
        const grouped = new Map<string | number, GroupedTOC>();

        for (const [i, item] of items.entries()) {
            const [id, fragment] = await splitHref(item?.href) ?? [];
            const value = { fragment, item };
            const existing = grouped.get(id);
            if (existing) {
                existing.items.push(value);
            } else {
                grouped.set(id, { prev: items[i - 1], items: [value] });
            }
        }

        const map = new Map<string | number, GroupedTOC | undefined>();
        for (const [i, id] of ids.entries()) {
            if (grouped.has(id)) {
                map.set(id, grouped.get(id));
            } else {
                map.set(id, map.get(ids[i - 1]));
            }
        }
        this.ids = ids;
        this.map = map;
        this.getFragment = getFragment;
    }

    getProgress(index: number, range?: Range | null): TOCItem | undefined | null {
        if (!this.ids || !this.map || !this.getFragment) return;

        const id = this.ids[index];
        const obj = this.map.get(id);
        if (!obj) return null;

        const { prev, items } = obj;
        if (!items) return prev;
        if (!range || (items.length === 1 && !items[0].fragment)) return items[0].item;

        const doc = range.startContainer.ownerDocument;
        if (!doc) return items[0].item;
        
        for (let i = items.length - 1; i >= 0; i--) {
            const { fragment } = items[i];
            const el = this.getFragment(doc, fragment);
            if (!el) continue;
            // if the start of the range is after or at the element
            if (range.comparePoint(el, 0) >= 0) {
                 return items[i].item;
            }
        }

        return prev;
    }
}

interface ProgressInfo {
    fraction: number;
    section: {
        current: number;
        total: number;
    };
    location: {
        current: number;
        next: number;
        total: number;
    };
    time: {
        section: number;
        total: number;
    };
}

export class SectionProgress {
    private sizes: number[];
    private sizePerLoc: number;
    private sizePerTimeUnit: number;
    private sizeTotal: number;
    public sectionFractions: number[];

    constructor(sections: Section[], sizePerLoc: number, sizePerTimeUnit: number) {
        this.sizes = sections.map(s => (s.linear !== 'no' && s.size > 0 ? s.size : 0));
        this.sizePerLoc = sizePerLoc;
        this.sizePerTimeUnit = sizePerTimeUnit;
        this.sizeTotal = this.sizes.reduce((a, b) => a + b, 0);
        this.sectionFractions = this.#getSectionFractions();
    }

    #getSectionFractions(): number[] {
        const { sizeTotal } = this;
        if (sizeTotal === 0) return [0];
        const results = [0];
        let sum = 0;
        for (const size of this.sizes) {
            results.push((sum += size) / sizeTotal);
        }
        return results;
    }

    getProgress(index: number, fractionInSection: number, pageFraction: number = 0): ProgressInfo {
        const { sizes, sizePerLoc, sizePerTimeUnit, sizeTotal } = this;
        const sizeInSection = sizes[index] ?? 0;
        const sizeBefore = sizes.slice(0, index).reduce((a, b) => a + b, 0);
        const size = sizeBefore + fractionInSection * sizeInSection;
        const nextSize = size + pageFraction * sizeInSection;
        const remainingTotal = sizeTotal - size;
        const remainingSection = (1 - fractionInSection) * sizeInSection;
        
        return {
            fraction: sizeTotal > 0 ? nextSize / sizeTotal : 0,
            section: {
                current: index,
                total: sizes.length,
            },
            location: {
                current: Math.floor(size / sizePerLoc),
                next: Math.floor(nextSize / sizePerLoc),
                total: Math.ceil(sizeTotal / sizePerLoc),
            },
            time: {
                section: remainingSection / sizePerTimeUnit,
                total: remainingTotal / sizePerTimeUnit,
            },
        };
    }

    getSection(fraction: number): [number, number] {
        if (fraction <= 0) return [0, 0];
        if (fraction >= 1) return [this.sizes.length - 1, 1];
        
        fraction = fraction + Number.EPSILON;
        const { sizeTotal } = this;
        if (sizeTotal === 0) return [0, 0];

        let index = this.sectionFractions.findIndex(x => x > fraction) - 1;
        if (index < 0) return [0, 0];
        
        while (!this.sizes[index] && index < this.sizes.length -1) {
            index++;
        }

        const sectionSize = this.sizes[index];
        if (sectionSize === 0) return [index, 0];

        const fractionInSection = (fraction - this.sectionFractions[index]) / (sectionSize / sizeTotal);
        return [index, fractionInSection];
    }
}
