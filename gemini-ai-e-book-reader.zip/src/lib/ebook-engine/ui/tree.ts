

import type { TOCItem } from '../types';

const createSVGElement = <K extends keyof SVGElementTagNameMap>(tag: K): SVGElementTagNameMap[K] =>
    document.createElementNS('http://www.w3.org/2000/svg', tag);

const createExpanderIcon = (): SVGSVGElement => {
    const svg = createSVGElement('svg');
    svg.setAttribute('viewBox', '0 0 13 10');
    svg.setAttribute('width', '13');
    svg.setAttribute('height', '13');
    const polygon = createSVGElement('polygon');
    polygon.setAttribute('points', '2 1, 12 1, 7 9');
    svg.append(polygon);
    return svg;
};

const createTOCItemElement = (
    list: HTMLElement[],
    map: Map<string, HTMLElement>,
    onclick: (href: string) => void
) => {
    let count = 0;
    const makeID = () => `toc-element-${count++}`;

    const createItem = (item: TOCItem, depth = 0): HTMLLIElement => {
        const { label, href, subitems } = item;
        const a = document.createElement(href ? 'a' : 'span');
        a.innerText = label;
        a.setAttribute('role', 'treeitem');
        a.tabIndex = -1;
        a.style.paddingInlineStart = `${(depth + 1) * 1.5}rem`;
        list.push(a);

        if (href) {
            if (!map.has(href)) map.set(href, a);
            (a as HTMLAnchorElement).href = href;
            a.onclick = event => {
                event.preventDefault();
                onclick(href);
            };
        } else {
            a.onclick = event => (a.firstElementChild as HTMLElement)?.click();
        }

        const li = document.createElement('li');
        li.setAttribute('role', 'none');
        li.append(a);

        if (subitems?.length) {
            a.setAttribute('aria-expanded', 'false');
            const expander = createExpanderIcon();
            expander.onclick = event => {
                event.preventDefault();
                event.stopPropagation();
                const expanded = a.getAttribute('aria-expanded');
                a.setAttribute('aria-expanded', expanded === 'true' ? 'false' : 'true');
            };
            a.prepend(expander);
            const ol = document.createElement('ol');
            ol.id = makeID();
            ol.setAttribute('role', 'group');
            a.setAttribute('aria-owns', ol.id);
            ol.replaceChildren(...subitems.map(subItem => createItem(subItem, depth + 1)));
            li.append(ol);
        }
        return li;
    };
    return createItem;
};

export const createTOCView = (toc: TOCItem[], onclick: (href: string) => void) => {
    const $toc = document.createElement('ol');
    $toc.setAttribute('role', 'tree');
    $toc.className = 'foliate-toc-tree'; // for styling

    // Add some basic styles
    const style = document.createElement('style');
    style.textContent = `
        .foliate-toc-tree {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .foliate-toc-tree li[role="none"] {
            margin: 0.25rem 0;
        }
        .foliate-toc-tree a[role="treeitem"], .foliate-toc-tree span[role="treeitem"] {
            display: flex;
            align-items: center;
            padding: 0.5rem 0.75rem;
            border-radius: 0.375rem;
            cursor: pointer;
            transition: background-color 0.2s;
            color: #d1d5db; /* gray-300 */
        }
        .foliate-toc-tree a[role="treeitem"]:hover, .foliate-toc-tree span[role="treeitem"]:hover {
            background-color: rgba(255, 255, 255, 0.05);
        }
        .foliate-toc-tree a[aria-current="page"] {
            background-color: #4f46e5; /* indigo-600 */
            color: white;
            font-weight: 600;
        }
        .foliate-toc-tree svg {
            margin-right: 0.5rem;
            transition: transform 0.2s;
            flex-shrink: 0;
        }
        .foliate-toc-tree [aria-expanded="true"] > svg {
            transform: rotate(180deg);
        }
        .foliate-toc-tree [aria-expanded="false"] + ol[role="group"] {
            display: none;
        }
        .foliate-toc-tree ol[role="group"] {
             list-style: none;
             padding-left: 0.5rem;
             border-left: 1px solid #4b5563; /* gray-600 */
             margin-left: 1rem; /* Adjust based on icon size */
        }
    `;
    $toc.appendChild(style);

    const list: HTMLElement[] = [];
    const map = new Map<string, HTMLElement>();
    const createItem = createTOCItemElement(list, map, onclick);
    $toc.append(...toc.map(item => createItem(item)));

    const isTreeItem = (item?: Element | null): item is HTMLElement => 
        item?.getAttribute('role') === 'treeitem';

    const getParents = function* (el: HTMLElement): Generator<HTMLElement> {
        for (let parent = el.parentElement; parent && parent !== $toc; parent = parent.parentElement) {
            const item = parent.previousElementSibling;
            if (isTreeItem(item)) yield item;
        }
    };

    let currentItem: HTMLElement | undefined;

    $toc.addEventListener('focusout', () => {
        if (!currentItem) return;
        if (currentItem.offsetParent) {
            currentItem.tabIndex = 0;
        }
    });

    const setCurrentHref = (href: string) => {
        if (currentItem) {
            currentItem.removeAttribute('aria-current');
            currentItem.tabIndex = -1;
        }
        const el = map.get(href);
        if (!el) {
            currentItem = list[0];
            if (currentItem) currentItem.tabIndex = 0;
            return;
        }
        for (const item of getParents(el)) {
            item.setAttribute('aria-expanded', 'true');
        }
        el.setAttribute('aria-current', 'page');
        el.tabIndex = 0;
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        currentItem = el;
    };

    const walker = document.createTreeWalker($toc, NodeFilter.SHOW_ELEMENT, {
        acceptNode: (node) => isTreeItem(node as HTMLElement) && (node as HTMLElement).offsetParent
            ? NodeFilter.FILTER_ACCEPT
            : NodeFilter.FILTER_SKIP
    });
    
    const getIter = (current: Node) => (walker.currentNode = current, walker);

    for (const el of list) {
        el.addEventListener('keydown', event => {
            const { currentTarget, key } = event;
            // Fix: Cast currentTarget to HTMLElement to access element-specific properties.
            const targetElement = currentTarget as HTMLElement;
            if(!isTreeItem(targetElement)) return;

            let stop = false;
            switch (key) {
                case ' ': case 'Enter':
                    targetElement.click();
                    stop = true;
                    break;
                case 'ArrowDown':
                    (getIter(targetElement).nextNode() as HTMLElement)?.focus();
                    stop = true;
                    break;
                case 'ArrowUp':
                    (getIter(targetElement).previousNode() as HTMLElement)?.focus();
                    stop = true;
                    break;
                case 'ArrowLeft':
                    if (targetElement.getAttribute('aria-expanded') === 'true') {
                        targetElement.setAttribute('aria-expanded', 'false');
                    } else {
                        getParents(targetElement).next()?.value?.focus();
                    }
                    stop = true;
                    break;
                case 'ArrowRight':
                    if (targetElement.getAttribute('aria-expanded') === 'true') {
                        (getIter(targetElement).nextNode() as HTMLElement)?.focus();
                    } else if (targetElement.getAttribute('aria-owns')) {
                        targetElement.setAttribute('aria-expanded', 'true');
                    }
                    stop = true;
                    break;
                case 'Home':
                    list[0]?.focus();
                    stop = true;
                    break;
                case 'End': {
                    const lastVisible = Array.from(list).reverse().find(item => item.offsetParent);
                    lastVisible?.focus();
                    stop = true;
                    break;
                }
            }
            if (stop) {
                event.preventDefault();
                event.stopPropagation();
            }
        });
    }

    return { element: $toc, setCurrentHref };
};