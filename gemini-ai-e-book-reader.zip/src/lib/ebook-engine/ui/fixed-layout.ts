
import type { Book, Section, Renderer } from '../types';

const parseViewport = (str?: string): { [key: string]: string } | undefined => {
    return str
        ?.split(/[,;\s]/)
        ?.filter(x => x)
        ?.map(x => x.split('=').map(y => y.trim()))
        .reduce((acc, [key, value]) => {
            if (key) acc[key] = value;
            return acc;
        }, {} as { [key: string]: string });
};

const getViewport = (doc: Document, viewport?: string | { width?: string, height?: string }): { width?: string, height?: string } => {
    if (doc.documentElement.localName === 'svg') {
        const [, , width, height] = doc.documentElement.getAttribute('viewBox')?.split(/\s/) ?? [];
        return { width, height };
    }

    const meta = parseViewport(doc.querySelector('meta[name="viewport"]')?.getAttribute('content') ?? undefined);
    if (meta) return meta;

    if (typeof viewport === 'string') return parseViewport(viewport);
    if (viewport?.width && viewport.height) return viewport;

    const img = doc.querySelector('img');
    if (img) return { width: String(img.naturalWidth), height: String(img.naturalHeight) };

    console.warn(new Error('Missing viewport properties'));
    return { width: '1000', height: '2000' };
};

interface Frame {
    element: HTMLDivElement;
    iframe: HTMLIFrameElement;
    blank?: boolean;
    width?: number;
    height?: number;
    onZoom?: (zoom: { doc: Document, scale: number }) => void;
}

interface Spread {
    left?: Section;
    right?: Section;
    center?: Section;
}

interface CreateFrameOptions {
    index: number;
    src: string | { src: string, onZoom?: (zoom: { doc: Document, scale: number }) => void } | undefined;
}

export class FixedLayout extends HTMLElement implements Renderer {
    static observedAttributes = ['zoom'];
    #root = this.attachShadow({ mode: 'closed' });
    #observer: ResizeObserver;
    #spreads: Spread[] = [];
    #index = -1;
    defaultViewport?: string;
    spread?: 'none' | 'auto' | 'landscape' | 'portrait' | 'both';
    #portrait = false;
    #left: Frame | null = null;
    #right: Frame | null = null;
    #center: Frame | null = null;
    #side: 'left' | 'right' | 'center' = 'left';
    #zoom: number | 'fit-width' | 'fit-page' = 'fit-page';
    public book!: Book;
    public rtl = false;

    constructor() {
        super();
        this.#observer = new ResizeObserver(() => this.#render());

        const sheet = new CSSStyleSheet();
        this.#root.adoptedStyleSheets = [sheet];
        sheet.replaceSync(`:host {
            width: 100%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: auto;
        }`);

        this.#observer.observe(this);
    }

    attributeChangedCallback(name: string, _: string, value: string) {
        if (name === 'zoom') {
            this.#zoom = value !== 'fit-width' && value !== 'fit-page' ? parseFloat(value) : value;
            this.#render();
        }
    }

    async #createFrame({ index, src: srcOption }: CreateFrameOptions): Promise<Frame> {
        const src = typeof srcOption === 'string' ? srcOption : srcOption?.src;
        const onZoom = typeof srcOption === 'object' ? srcOption.onZoom : undefined;

        const element = document.createElement('div');
        element.setAttribute('dir', 'ltr');
        const iframe = document.createElement('iframe');
        element.append(iframe);
        Object.assign(iframe.style, {
            border: '0',
            display: 'none',
            overflow: 'hidden',
        });
        iframe.setAttribute('sandbox', 'allow-same-origin allow-scripts');
        iframe.setAttribute('scrolling', 'no');
        iframe.setAttribute('part', 'filter');
        this.#root.append(element);
        
        if (!src) return { blank: true, element, iframe };

        return new Promise(resolve => {
            iframe.addEventListener('load', () => {
                const doc = iframe.contentDocument!;
                this.dispatchEvent(new CustomEvent('load', { detail: { doc, index } }));
                const { width, height } = getViewport(doc, this.defaultViewport);
                resolve({
                    element, iframe,
                    width: parseFloat(width || '0'),
                    height: parseFloat(height || '0'),
                    onZoom,
                });
            }, { once: true });
            iframe.src = src;
        });
    }
    
    #render(side: 'left' | 'right' | 'center' | undefined = this.#side) {
        if (!side) return;
        const left = this.#left || {} as Frame;
        const right = this.#center || this.#right || {} as Frame;
        const target = side === 'left' ? left : right;
        const { width, height } = this.getBoundingClientRect();
        const portrait = this.spread !== 'both' && this.spread !== 'portrait' && height > width;
        this.#portrait = portrait;
        const blankWidth = left.width ?? right.width ?? 0;
        const blankHeight = left.height ?? right.height ?? 0;
        
        const scale = typeof this.#zoom === 'number' && !isNaN(this.#zoom) ? this.#zoom
            : (this.#zoom === 'fit-width'
                ? (portrait || this.#center
                    ? width / (target.width ?? blankWidth)
                    : width / ((left.width ?? blankWidth) + (right.width ?? blankWidth)))
                : (portrait || this.#center
                    ? Math.min(width / (target.width ?? blankWidth), height / (target.height ?? blankHeight))
                    : Math.min(width / ((left.width ?? blankWidth) + (right.width ?? blankWidth)), height / Math.max(left.height ?? blankHeight, right.height ?? blankHeight)))
            ) || 1;
        
        const transform = (frame: Frame) => {
            if (!frame.iframe) return;
            if (frame.onZoom) frame.onZoom({ doc: frame.iframe.contentDocument!, scale });
            const iframeScale = frame.onZoom ? scale : 1;
            Object.assign(frame.iframe.style, {
                width: `${(frame.width || 0) * iframeScale}px`,
                height: `${(frame.height || 0) * iframeScale}px`,
                transform: frame.onZoom ? 'none' : `scale(${scale})`,
                transformOrigin: 'top left',
                display: frame.blank ? 'none' : 'block',
            });
            Object.assign(frame.element.style, {
                width: `${((frame.width ?? blankWidth)) * scale}px`,
                height: `${((frame.height ?? blankHeight)) * scale}px`,
                overflow: 'hidden',
                display: 'block',
                flexShrink: '0',
                marginBlock: 'auto',
            });
            if (portrait && frame !== target) {
                frame.element.style.display = 'none';
            }
        };

        if (this.#center) transform(this.#center);
        else {
            if (this.#left) transform(this.#left);
            if (this.#right) transform(this.#right);
        }
    }
    
    async #showSpread({ left, right, center, side }: any) {
        this.#root.replaceChildren();
        this.#left = this.#right = this.#center = null;

        if (center) {
            this.#center = await this.#createFrame(center);
            this.#side = 'center';
            this.#render();
        } else {
            this.#left = await this.#createFrame(left);
            this.#right = await this.#createFrame(right);
            this.#side = this.#left.blank ? 'right' : (this.#right.blank ? 'left' : side);
            this.#render();
        }
    }

    #goLeft(): boolean | undefined {
        if (this.#center || this.#left?.blank) return;
        if (this.#portrait && this.#left?.element?.style?.display === 'none') {
            this.#side = 'left';
            this.#render();
            this.#reportLocation('page');
            return true;
        }
    }

    #goRight(): boolean | undefined {
        if (this.#center || this.#right?.blank) return;
        if (this.#portrait && this.#right?.element?.style?.display === 'none') {
            this.#side = 'right';
            this.#render();
            this.#reportLocation('page');
            return true;
        }
    }

    open(book: Book) {
        this.book = book;
        const { rendition } = book;
        this.spread = rendition?.spread;
        this.defaultViewport = rendition?.viewport;
        const rtl = book.dir === 'rtl';
        this.rtl = rtl;
        
        if (rendition?.spread === 'none') {
            this.#spreads = book.sections.map(section => ({ center: section }));
        } else {
            this.#spreads = book.sections.reduce((arr, section, i) => {
                let last = arr[arr.length - 1];
                if (!last) {
                    last = {};
                    arr.push(last);
                }
                const { pageSpread } = section;

                if (pageSpread === 'center') {
                    if (last.left || last.right) last = arr[arr.push({}) - 1];
                    last.center = section;
                } else if (pageSpread === 'left') {
                    if (last.center || last.left || (!rtl && i)) last = arr[arr.push({}) - 1];
                    last.left = section;
                } else if (pageSpread === 'right') {
                    if (last.center || last.right || (rtl && i)) last = arr[arr.push({}) - 1];
                    last.right = section;
                } else if (!rtl) { // LTR
                    if (last.center || last.right) arr.push({ left: section });
                    else if (last.left || !i) last.right = section;
                    else last.left = section;
                } else { // RTL
                    if (last.center || last.left) arr.push({ right: section });
                    else if (last.right || !i) last.left = section;
                    else last.right = section;
                }
                return arr;
            }, [] as Spread[]);
        }
    }

    #reportLocation(reason: string) {
        const spread = this.#spreads[this.#index];
        const section = spread?.center ?? (this.#side === 'left'
            ? spread.left ?? spread.right : spread.right ?? spread.left);
        const index = section ? this.book.sections.indexOf(section) : -1;
        this.dispatchEvent(new CustomEvent('relocate', { detail:
            { reason, range: null, index, fraction: 0, size: 1 } }));
    }

    getSpreadOf(section: Section): { index: number, side: 'left' | 'right' | 'center' } | undefined {
        for (let index = 0; index < this.#spreads.length; index++) {
            const { left, right, center } = this.#spreads[index];
            if (left === section) return { index, side: 'left' };
            if (right === section) return { index, side: 'right' };
            if (center === section) return { index, side: 'center' };
        }
    }

    async goToSpread(index: number, side: 'left' | 'right' | 'center', reason?: string) {
        if (index < 0 || index >= this.#spreads.length) return;
        if (index === this.#index) {
            this.#render(side);
            return;
        }
        this.#index = index;
        const spread = this.#spreads[index];
        const { center, left, right } = spread;

        if (center) {
            const src = await center.load();
            await this.#showSpread({ center: { index: this.book.sections.indexOf(center), src } });
        } else {
            const [srcL, srcR] = await Promise.all([left?.load(), right?.load()]);
            await this.#showSpread({
                left: { index: left ? this.book.sections.indexOf(left) : -1, src: srcL },
                right: { index: right ? this.book.sections.indexOf(right) : -1, src: srcR },
                side
            });
        }
        this.#reportLocation(reason || 'navigation');
    }
    
    async goTo(target: any) {
        const resolved = await Promise.resolve(target);
        if (resolved === undefined || resolved === null) return;
        const section = this.book.sections[resolved.index];
        if (!section) return;
        const spreadInfo = this.getSpreadOf(section);
        if (spreadInfo) {
            await this.goToSpread(spreadInfo.index, spreadInfo.side);
        }
    }

    async scrollToAnchor() { /* no-op for fixed layout */ }

    async next() {
        if (!(this.rtl ? this.#goLeft() : this.#goRight())) {
            await this.goToSpread(this.#index + 1, this.rtl ? 'right' : 'left', 'page');
        }
    }

    async prev() {
        if (!(this.rtl ? this.#goRight() : this.#goLeft())) {
            await this.goToSpread(this.#index - 1, this.rtl ? 'left' : 'right', 'page');
        }
    }
    
    getContents(): { doc: Document }[] {
        return Array.from(this.#root.querySelectorAll('iframe'))
            .filter(frame => frame.contentDocument)
            .map(frame => ({ doc: frame.contentDocument! }));
    }

    destroy() {
        this.#observer.disconnect();
    }
}

customElements.define('foliate-fxl', FixedLayout);
