
const createSVGElement = <K extends keyof SVGElementTagNameMap>(tag: K): SVGElementTagNameMap[K] =>
    document.createElementNS('http://www.w3.org/2000/svg', tag);

interface DrawOptions {
    color?: string;
    width?: number;
    writingMode?: string;
    radius?: number;
    src?: string;
}

type DrawFunction = (rects: DOMRectList, options?: DrawOptions) => SVGElement;

interface MapEntry {
    range: Range | (() => Range);
    draw: DrawFunction;
    options?: DrawOptions;
    element: SVGElement;
    rects: DOMRectList;
}

export class Overlayer {
    #svg: SVGSVGElement = createSVGElement('svg');
    #map: Map<any, MapEntry> = new Map();

    constructor() {
        Object.assign(this.#svg.style, {
            position: 'absolute', top: '0', left: '0',
            width: '100%', height: '100%',
            pointerEvents: 'none',
        });
    }

    get element(): SVGSVGElement {
        return this.#svg;
    }

    add(key: any, range: Range | (() => Range), draw: DrawFunction, options?: DrawOptions): void {
        if (this.#map.has(key)) this.remove(key);
        const effectiveRange = typeof range === 'function' ? range() : range;
        if (!effectiveRange) return;
        
        const rects = effectiveRange.getClientRects();
        const element = draw(rects, options);
        this.#svg.append(element);
        this.#map.set(key, { range, draw, options, element, rects });
    }

    remove(key: any): void {
        const entry = this.#map.get(key);
        if (!entry) return;
        if (entry.element.parentNode) {
            this.#svg.removeChild(entry.element);
        }
        this.#map.delete(key);
    }

    redraw(): void {
        for (const obj of this.#map.values()) {
            const { range, draw, options, element } = obj;
            if (element.parentNode) {
                this.#svg.removeChild(element);
            }
            const effectiveRange = typeof range === 'function' ? range() : range;
            if(!effectiveRange) continue;

            const rects = effectiveRange.getClientRects();
            const el = draw(rects, options);
            this.#svg.append(el);
            obj.element = el;
            obj.rects = rects;
        }
    }

    hitTest({ x, y }: MouseEvent): [any, Range] | [] {
        const arr = Array.from(this.#map.entries());
        // loop in reverse to hit more recently added items first
        for (let i = arr.length - 1; i >= 0; i--) {
            const [key, obj] = arr[i];
            for (const { left, top, right, bottom } of obj.rects) {
                if (top <= y && left <= x && bottom > y && right > x) {
                    const effectiveRange = typeof obj.range === 'function' ? obj.range() : obj.range;
                    return effectiveRange ? [key, effectiveRange] : [];
                }
            }
        }
        return [];
    }

    static underline(rects: DOMRectList, options: DrawOptions = {}): SVGGElement {
        const { color = 'red', width: strokeWidth = 2, writingMode } = options;
        const g = createSVGElement('g');
        g.setAttribute('fill', color);
        if (writingMode === 'vertical-rl' || writingMode === 'vertical-lr') {
            for (const { right, top, height } of rects) {
                const el = createSVGElement('rect');
                el.setAttribute('x', String(right - strokeWidth));
                el.setAttribute('y', String(top));
                el.setAttribute('height', String(height));
                el.setAttribute('width', String(strokeWidth));
                g.append(el);
            }
        } else {
            for (const { left, bottom, width } of rects) {
                const el = createSVGElement('rect');
                el.setAttribute('x', String(left));
                el.setAttribute('y', String(bottom - strokeWidth));
                el.setAttribute('height', String(strokeWidth));
                el.setAttribute('width', String(width));
                g.append(el);
            }
        }
        return g;
    }

    static strikethrough(rects: DOMRectList, options: DrawOptions = {}): SVGGElement {
        const { color = 'red', width: strokeWidth = 2, writingMode } = options;
        const g = createSVGElement('g');
        g.setAttribute('fill', color);
        if (writingMode === 'vertical-rl' || writingMode === 'vertical-lr') {
            for (const { right, left, top, height } of rects) {
                const el = createSVGElement('rect');
                el.setAttribute('x', String((right + left) / 2));
                el.setAttribute('y', String(top));
                el.setAttribute('height', String(height));
                el.setAttribute('width', String(strokeWidth));
                g.append(el);
            }
        } else {
            for (const { left, top, bottom, width } of rects) {
                const el = createSVGElement('rect');
                el.setAttribute('x', String(left));
                el.setAttribute('y', String((top + bottom) / 2));
                el.setAttribute('height', String(strokeWidth));
                el.setAttribute('width', String(width));
                g.append(el);
            }
        }
        return g;
    }

    static squiggly(rects: DOMRectList, options: DrawOptions = {}): SVGGElement {
        const { color = 'red', width: strokeWidth = 2, writingMode } = options;
        const g = createSVGElement('g');
        g.setAttribute('fill', 'none');
        g.setAttribute('stroke', color);
        g.setAttribute('stroke-width', String(strokeWidth));
        const block = strokeWidth * 1.5;
        if (writingMode === 'vertical-rl' || writingMode === 'vertical-lr') {
            for (const { right, top, height } of rects) {
                const el = createSVGElement('path');
                const n = Math.round(height / block / 1.5);
                const inline = height / n;
                const ls = Array.from({ length: n },
                    (_, i) => `l${i % 2 ? -block : block} ${inline}`).join('');
                el.setAttribute('d', `M${right} ${top}${ls}`);
                g.append(el);
            }
        } else {
            for (const { left, bottom, width } of rects) {
                const el = createSVGElement('path');
                const n = Math.round(width / block / 1.5);
                const inline = width / n;
                const ls = Array.from({ length: n },
                    (_, i) => `l${inline} ${i % 2 ? block : -block}`).join('');
                el.setAttribute('d', `M${left} ${bottom}${ls}`);
                g.append(el);
            }
        }
        return g;
    }

    static highlight(rects: DOMRectList, options: DrawOptions = {}): SVGGElement {
        const { color = 'yellow' } = options;
        const g = createSVGElement('g');
        g.setAttribute('fill', color);
        g.style.opacity = 'var(--overlayer-highlight-opacity, .3)';
        g.style.mixBlendMode = 'var(--overlayer-highlight-blend-mode, multiply)';
        for (const { left, top, height, width } of rects) {
            const el = createSVGElement('rect');
            el.setAttribute('x', String(left));
            el.setAttribute('y', String(top));
            el.setAttribute('height', String(height));
            el.setAttribute('width', String(width));
            g.append(el);
        }
        return g;
    }

    static outline(rects: DOMRectList, options: DrawOptions = {}): SVGGElement {
        const { color = 'blue', width: strokeWidth = 3, radius = 3 } = options;
        const g = createSVGElement('g');
        g.setAttribute('fill', 'none');
        g.setAttribute('stroke', color);
        g.setAttribute('stroke-width', String(strokeWidth));
        g.style.opacity = '0.5';
        for (const { left, top, height, width } of rects) {
            const el = createSVGElement('rect');
            el.setAttribute('x', String(left));
            el.setAttribute('y', String(top));
            el.setAttribute('height', String(height));
            el.setAttribute('width', String(width));
            el.setAttribute('rx', String(radius));
            g.append(el);
        }
        return g;
    }

    static copyImage(rects: DOMRectList, options: DrawOptions = {}): SVGImageElement {
        const { src } = options;
        const image = createSVGElement('image');
        const rect = rects[0];
        if (rect && src) {
            const { left, top, height, width } = rect;
            image.setAttribute('href', src);
            image.setAttribute('x', String(left));
            image.setAttribute('y', String(top));
            image.setAttribute('height', String(height));
            image.setAttribute('width', String(width));
        }
        return image;
    }
}
