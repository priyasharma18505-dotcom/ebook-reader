
interface RadioItem {
    label: string;
    value: any;
}

interface RadioGroupConfig {
    name: string;
    label: string;
    type: 'radio';
    items: [string, any][];
    onclick: (value: any) => void;
}

interface MenuItemRadioGroup {
    element: HTMLUListElement;
    select: (value: any) => void;
}

const createMenuItemRadioGroup = (label: string, items: [string, any][], onclick: (value: any) => void): MenuItemRadioGroup => {
    const group = document.createElement('ul');
    group.setAttribute('role', 'group');
    group.setAttribute('aria-label', label);
    const map = new Map<any, HTMLLIElement>();

    const select = (value: any) => {
        onclick(value);
        const item = map.get(value);
        for (const child of Array.from(group.children)) {
            child.setAttribute('aria-checked', child === item ? 'true' : 'false');
        }
    };

    for (const [itemLabel, value] of items) {
        const item = document.createElement('li');
        item.setAttribute('role', 'menuitemradio');
        item.innerText = itemLabel;
        item.onclick = () => select(value);
        map.set(value, item);
        group.append(item);
    }

    return { element: group, select };
};

export const createMenu = (arr: RadioGroupConfig[]) => {
    const groups: { [key: string]: MenuItemRadioGroup } = {};
    const element = document.createElement('ul');
    element.setAttribute('role', 'menu');

    const hide = () => element.classList.remove('show');
    const hideAnd = <T extends (...args: any[]) => void>(f: T) => (...args: Parameters<T>): void => {
        hide();
        f(...args);
    };

    for (const { name, label, type, items, onclick } of arr) {
        if (type === 'radio') {
            const widget = createMenuItemRadioGroup(label, items, hideAnd(onclick));
            groups[name] = widget;
            element.append(widget.element);
        }
    }

    const clickOutsideHandler = (e: MouseEvent) => {
        if (!element.parentElement?.contains(e.target as Node)) {
            hide();
        }
    };

    const blurHandler = () => {
        // Use a timeout to allow click events on menu items to register before hiding
        setTimeout(() => {
            if (document.activeElement && !element.contains(document.activeElement)) {
                hide();
            }
        }, 150);
    };

    // Assuming the menu is shown by adding a 'show' class to its parent or itself
    const observer = new MutationObserver(() => {
        if (element.classList.contains('show')) {
            window.addEventListener('blur', blurHandler, true);
            window.addEventListener('click', clickOutsideHandler, true);
        } else {
            window.removeEventListener('blur', blurHandler, true);
            window.removeEventListener('click', clickOutsideHandler, true);
        }
    });

    observer.observe(element, { attributes: true, attributeFilter: ['class'] });

    return { element, groups };
};
