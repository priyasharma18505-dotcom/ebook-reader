type MakeRangeFunc = (startIndex: number, startOffset: number, endIndex: number, endOffset: number) => Range;
type SegmenterFunc = (strs: string[], makeRange: MakeRangeFunc) => Generator<[string, Range]>;

const walkRange = (range: Range, walker: TreeWalker): Node[] => {
    const nodes: Node[] = [];
    for (let node = walker.currentNode; node; node = walker.nextNode()) {
        const compare = range.comparePoint(node, 0);
        if (compare === 0) {
            nodes.push(node);
        } else if (compare > 0) {
            break;
        }
    }
    return nodes;
}

const walkDocument = (doc: Document | DocumentFragment, walker: TreeWalker): Node[] => {
    const nodes: Node[] = [];
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
        nodes.push(node);
    }
    return nodes;
}

const filter = NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT | NodeFilter.SHOW_CDATA_SECTION;

const acceptNodeDefault = (node: Node): number => {
    if (node.nodeType === Node.ELEMENT_NODE) {
        const name = (node as Element).tagName.toLowerCase();
        if (name === 'script' || name === 'style') {
            return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_SKIP;
    }
    return NodeFilter.FILTER_ACCEPT;
}

export function* textWalker<T = [string, Range]>(
    x: Range | Document | DocumentFragment, 
    func: (strs: string[], makeRange: MakeRangeFunc) => Generator<T>, 
    filterFunc?: (node: Node) => number
): Generator<T> {
    const root: Node = x instanceof Range 
        ? x.commonAncestorContainer 
        : (x instanceof Document && x.body) 
        ? x.body 
        : x;
    
    const walker = document.createTreeWalker(root, filter, { acceptNode: filterFunc || acceptNodeDefault });
    
    const nodes = x instanceof Range
        ? walkRange(x, walker)
        : walkDocument(x, walker);
    
    const strs = nodes.map(node => node.nodeValue || '');
    
    const makeRange: MakeRangeFunc = (startIndex, startOffset, endIndex, endOffset): Range => {
        const range = document.createRange();
        range.setStart(nodes[startIndex], startOffset);
        range.setEnd(nodes[endIndex], endOffset);
        return range;
    }

    for (const match of func(strs, makeRange)) {
        yield match;
    }
}