

export const wait = (ms: number): Promise<void> => new Promise(resolve => setTimeout(resolve, ms));

export const debounce = <T extends (...args: any[]) => void>(f: T, wait: number, immediate?: boolean): ((...args: Parameters<T>) => void) => {
    let timeout: number | null;
    return (...args: Parameters<T>) => {
        const later = () => {
            timeout = null;
            if (!immediate) f(...args);
        };
        const callNow = immediate && !timeout;
        if (timeout) clearTimeout(timeout);
        timeout = window.setTimeout(later, wait);
        if (callNow) f(...args);
    };
};

export const lerp = (min: number, max: number, x: number): number => x * (max - min) + min;
export const easeOutQuad = (x: number): number => 1 - (1 - x) * (1 - x);

export const animate = (a: number, b: number, duration: number, ease: (t: number) => number, render: (val: number) => void): Promise<void> => new Promise(resolve => {
    let start: number;
    const step = (now: number) => {
        if (document.hidden) {
            render(lerp(a, b, 1));
            return resolve();
        }
        start ??= now;
        const fraction = Math.min(1, (now - start) / duration);
        render(lerp(a, b, ease(fraction)));
        if (fraction < 1) {
            requestAnimationFrame(step);
        } else {
            resolve();
        }
    };
    if (document.hidden) {
        render(lerp(a, b, 1));
        return resolve();
    }
    requestAnimationFrame(step);
});

export const uncollapse = (range: Range): Range | Node | null => {
    if (!range?.collapsed) return range;
    const { endOffset, endContainer } = range;
    if (endContainer.nodeType === Node.ELEMENT_NODE) {
        const node = endContainer.childNodes[endOffset];
        if (node?.nodeType === Node.ELEMENT_NODE) return node;
        return endContainer;
    }
    if (endOffset + 1 < (endContainer.nodeValue?.length ?? 0)) {
        range.setEnd(endContainer, endOffset + 1);
    } else if (endOffset > 1) {
        range.setStart(endContainer, endOffset - 1);
    } else {
        return endContainer.parentNode;
    }
    return range;
};

export const makeRange = (doc: Document, node: Node, start: number, end: number = start): Range => {
    const range = doc.createRange();
    range.setStart(node, start);
    range.setEnd(node, end);
    return range;
};

export const bisectNode = (doc: Document, node: Text, cb: (a: Range, b: Range) => number, start: number = 0, end: number = node.nodeValue?.length ?? 0): number => {
    if (end - start <= 1) {
        const result = cb(makeRange(doc, node, start), makeRange(doc, node, end));
        return result < 0 ? start : end;
    }
    const mid = Math.floor(start + (end - start) / 2);
    const result = cb(makeRange(doc, node, start, mid), makeRange(doc, node, mid, end));
    return result < 0 ? bisectNode(doc, node, cb, start, mid)
        : result > 0 ? bisectNode(doc, node, cb, mid, end) : mid;
};

export const getBoundingClientRect = (target: Element | Range): DOMRect => {
    let top = Infinity, right = -Infinity, left = Infinity, bottom = -Infinity;
    for (const rect of target.getClientRects()) {
        left = Math.min(left, rect.left);
        top = Math.min(top, rect.top);
        right = Math.max(right, rect.right);
        bottom = Math.max(bottom, rect.bottom);
    }
    return new DOMRect(left, top, right - left, bottom - top);
};

export const getVisibleRange = (doc: Document, start: number, end: number, mapRect: (rect: DOMRect) => { left: number; right: number }): Range => {
    // Fix: Correctly type the acceptNode function.
    const acceptNode = (node: Node): number => {
        const name = (node as Element).localName?.toLowerCase();
        if (name === 'script' || name === 'style') return NodeFilter.FILTER_REJECT;
        if (node.nodeType === Node.ELEMENT_NODE) {
            const { left, right } = mapRect((node as Element).getBoundingClientRect());
            if (right < start || left > end) return NodeFilter.FILTER_REJECT;
            if (left >= start && right <= end) return NodeFilter.FILTER_ACCEPT;
        } else {
            if (!(node.nodeValue?.trim())) return NodeFilter.FILTER_SKIP;
            const range = doc.createRange();
            range.selectNodeContents(node);
            const { left, right } = mapRect(range.getBoundingClientRect());
            if (right >= start && left <= end) return NodeFilter.FILTER_ACCEPT;
        }
        return NodeFilter.FILTER_SKIP;
    };

    const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, { acceptNode });
    const nodes: Node[] = [];
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
        nodes.push(node);
    }

    const from = nodes[0] ?? doc.body;
    const to = nodes[nodes.length - 1] ?? from;

    const startOffset = from.nodeType === Node.ELEMENT_NODE ? 0 : bisectNode(doc, from as Text, (a, b) => {
        const p = mapRect(getBoundingClientRect(a));
        const q = mapRect(getBoundingClientRect(b));
        if (p.right < start && q.left > start) return 0;
        return q.left > start ? -1 : 1;
    });

    const endOffset = to.nodeType === Node.ELEMENT_NODE ? (to as Element).childNodes.length : bisectNode(doc, to as Text, (a, b) => {
        const p = mapRect(getBoundingClientRect(a));
        const q = mapRect(getBoundingClientRect(b));
        if (p.right < end && q.left > end) return 0;
        return q.left > end ? -1 : 1;
    });

    const range = doc.createRange();
    range.setStart(from, startOffset);
    range.setEnd(to, endOffset);
    return range;
};

export const selectionIsBackward = (sel: Selection): boolean => {
    if (sel.rangeCount === 0 || sel.isCollapsed) return false;
    const range = document.createRange();
    range.setStart(sel.anchorNode!, sel.anchorOffset);
    range.setEnd(sel.focusNode!, sel.focusOffset);
    return range.collapsed;
};

export const setSelectionTo = (target: Range | Node | null, collapse: -1 | 0 | 1): void => {
    if (!target) return;
    let range: Range;
    if (target instanceof Range) {
        range = target.cloneRange();
    } else if (target.nodeType) {
        range = document.createRange();
        range.selectNode(target);
    } else {
        return;
    }
    
    const sel = range.startContainer.ownerDocument?.defaultView?.getSelection();
    if (sel) {
        sel.removeAllRanges();
        if (collapse === -1) range.collapse(true);
        else if (collapse === 1) range.collapse(false);
        sel.addRange(range);
    }
};

export const getDirection = (doc: Document): { vertical: boolean; rtl: boolean } => {
    if (!doc.body) return { vertical: false, rtl: false };
    const { defaultView } = doc;
    const { writingMode, direction } = defaultView.getComputedStyle(doc.body);
    const vertical = writingMode === 'vertical-rl' || writingMode === 'vertical-lr';
    const rtl = doc.body.dir === 'rtl' || direction === 'rtl' || doc.documentElement.dir === 'rtl';
    return { vertical, rtl };
};

export const getBackground = (doc: Document): string => {
    if (!doc.body || !doc.defaultView) return 'transparent';
    const bodyStyle = doc.defaultView.getComputedStyle(doc.body);
    const isTransparent = bodyStyle.backgroundColor === 'rgba(0, 0, 0, 0)' || bodyStyle.backgroundColor === 'transparent';
    return isTransparent && bodyStyle.backgroundImage === 'none'
        ? doc.defaultView.getComputedStyle(doc.documentElement).background
        : bodyStyle.background;
};

export const makeMarginals = (length: number, part: string): HTMLElement[] => Array.from({ length }, () => {
    const div = document.createElement('div');
    const child = document.createElement('div');
    div.append(child);
    child.setAttribute('part', part);
    return div;
});

export const setStylesImportant = (el: HTMLElement, styles: Partial<CSSStyleDeclaration>): void => {
    for (const [k, v] of Object.entries(styles)) {
        el.style.setProperty(k, v as string, 'important');
    }
};