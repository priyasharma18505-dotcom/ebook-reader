
import { useState, useEffect } from 'react';
import type { Book, BookView } from '../lib/ebook-engine/types';
import { View } from '../lib/ebook-engine/view';

export function useBook(book: Book) {
    const [view, setView] = useState<BookView | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        let viewInstance: BookView | null = null;
        const load = async () => {
            try {
                console.log('[EBookReader:useBook] Initializing book view...');
                setLoading(true);
                viewInstance = new View();
                await viewInstance.open(book);
                await viewInstance.init({});
                console.log('[EBookReader:useBook] Book view initialized successfully.');
                setView(viewInstance);
            } catch (error) {
                console.error("[EBookReader:useBook] Failed to initialize book view:", error);
            } finally {
                setLoading(false);
            }
        };

        load();

        return () => {
            console.log('[EBookReader:useBook] Destroying book view instance.');
            viewInstance?.destroy();
        };
    }, [book]);

    return { view, loading };
}