
import { useState, useCallback, useRef, useEffect } from 'react';
import type { BookView } from '../lib/ebook-engine/types';
import { geminiTTS } from '../services/gemini';
import { TTS } from '../lib/ebook-engine/core/tts';
import { textWalker } from '../lib/ebook-engine/utils/text-walker';
import { AudioPlayer } from '../utils/AudioPlayer';

export function useGeminiTTS(view: BookView | null) {
    const [isPlaying, setIsPlaying] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const ttsInstanceRef = useRef<TTS | null>(null);
    const audioPlayerRef = useRef<AudioPlayer | null>(null);
    const isStoppedRef = useRef(false);

    // Initialize AudioPlayer on mount and clean up on unmount
    useEffect(() => {
        audioPlayerRef.current = new AudioPlayer();
        return () => {
            audioPlayerRef.current?.stop();
        };
    }, []);

    const highlight = useCallback((range: Range) => {
        if (!view) return;
        view.renderer.scrollToAnchor(range, true);
    }, [view]);

    const initializeTTS = useCallback(() => {
        if (!view || ttsInstanceRef.current) return;
        const contents = view.renderer.getContents();
        if (contents && contents.length > 0) {
            const doc = contents[0].doc;
            ttsInstanceRef.current = new TTS(doc, textWalker, highlight, 'word');
        }
    }, [view, highlight]);
    
    const next = useCallback(() => {
        if (!ttsInstanceRef.current || isStoppedRef.current) return;
        const [ssml, range] = ttsInstanceRef.current.next(true) || [];
        if (ssml) {
            speak(ssml, range);
        } else {
            // End of book
            stop();
        }
    }, []);

    const speak = useCallback(async (ssml: string, range?: Range) => {
        if (!ssml || isStoppedRef.current) {
            setIsPlaying(false);
            setIsLoading(false);
            return;
        }

        setIsLoading(true);
        if (range) {
            highlight(range);
        }
        
        try {
          const parser = new DOMParser();
          const xmlDoc = parser.parseFromString(ssml, "text/xml");
          const textContent = xmlDoc.documentElement.textContent || "";
          
          if(!textContent.trim()) {
              next();
              return;
          }

          const audioContent = await geminiTTS(textContent);
          if (audioContent && !isStoppedRef.current && audioPlayerRef.current) {
            await audioPlayerRef.current.play(audioContent, () => {
                if (!isStoppedRef.current) {
                    next();
                }
            });
          } else {
             next();
          }
        } catch (error) {
            console.error("Error processing SSML or generating speech:", error);
            next(); // Try next block on error
        } finally {
            setIsLoading(false);
        }
    }, [highlight, next]);

    const play = useCallback(() => {
        if (!ttsInstanceRef.current) initializeTTS();
        if (!ttsInstanceRef.current) return;
        
        isStoppedRef.current = false;
        setIsPlaying(true);
        const [ssml, range] = ttsInstanceRef.current.resume() || [];
        if (ssml) {
            speak(ssml, range);
        }
    }, [initializeTTS, speak]);

    const pause = useCallback(() => {
        setIsPlaying(false);
        audioPlayerRef.current?.pause();
    }, []);

    const start = useCallback(() => {
        if (!ttsInstanceRef.current) initializeTTS();
        if (!ttsInstanceRef.current) return;

        isStoppedRef.current = false;
        setIsPlaying(true);
        const [ssml, range] = ttsInstanceRef.current.start() || [];
        if (ssml) {
            speak(ssml, range);
        }
    }, [initializeTTS, speak]);
    
    const stop = useCallback(() => {
        isStoppedRef.current = true;
        setIsPlaying(false);
        audioPlayerRef.current?.stop();
        ttsInstanceRef.current = null; // Reset instance
    }, []);

    const togglePlay = useCallback(() => {
        if (isPlaying) {
            pause();
        } else {
            play();
        }
    }, [isPlaying, pause, play]);

    const prev = useCallback(() => {
        if (!ttsInstanceRef.current || isStoppedRef.current) return;
        const [ssml, range] = ttsInstanceRef.current.prev(true) || [];
        if (ssml) {
            speak(ssml, range);
        }
    }, [speak]);

    return { isPlaying, isLoading, start, stop, togglePlay, next, prev };
}
