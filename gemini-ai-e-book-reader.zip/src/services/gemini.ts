
import { GoogleGenAI } from '@google/genai';

// Lazily initialize the AI client to prevent startup errors.
let ai: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI {
    if (!ai) {
        if (!process.env.API_KEY) {
            const errorMessage = "API_KEY environment variable not set. Please set it in your environment.";
            console.error(errorMessage);
            // This will prevent TTS from working, but allows the app to load.
            throw new Error(errorMessage);
        }
        ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    }
    return ai;
}


export async function geminiTTS(text: string): Promise<string | null> {
    if (!text.trim()) {
        return null;
    }
    try {
        const genAI = getAiClient();
        const response = await genAI.models.generateContent({
            model: "gemini-2.5-flash-preview-tts",
            contents: [{ parts: [{ text: text }] }],
            config: {
                // Fix: Corrected responseModalities to use a string literal 'AUDIO' as per library updates.
                responseModalities: ['AUDIO'],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: 'Kore' },
                    },
                },
            },
        });
        
        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        return base64Audio || null;
    } catch (error) {
        console.error("Gemini TTS API error:", error);
        return null;
    }
}