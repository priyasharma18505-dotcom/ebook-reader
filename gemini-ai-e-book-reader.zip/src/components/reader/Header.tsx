
import React from 'react';
import type { Book } from '../../lib/ebook-engine/types';
import { MenuIcon } from '../ui/Icons';

const Header: React.FC<{ book: Book | null; onMenuClick: () => void; show: boolean }> = ({ book, onMenuClick, show }) => (
    <header className={`fixed top-0 left-0 right-0 h-16 bg-slate-800/80 backdrop-blur-lg text-white flex items-center justify-between px-4 z-30 transition-transform duration-300 ease-in-out ${show ? 'translate-y-0' : '-translate-y-full'}`}>
        <button onClick={onMenuClick} className="p-2 rounded-full hover:bg-slate-700/50 transition-colors">
            <MenuIcon className="h-6 w-6" />
        </button>
        <div className="text-center overflow-hidden">
            <h1 className="font-bold truncate text-slate-100">{book?.metadata?.title as string}</h1>
            <p className="text-xs text-slate-400 truncate">{Array.isArray(book?.metadata?.author) ? book.metadata.author.map(a => a.name).join(', ') : book?.metadata?.author?.name as string}</p>
        </div>
        <div className="w-10"></div>
    </header>
);

export default Header;
