
import React, { useState, useEffect } from 'react';
import type { BookView } from '../../lib/ebook-engine/types';
import { useGeminiTTS } from '../../hooks/useGeminiTTS';
import { ChevronLeftIcon, ChevronRightIcon, PauseIcon, SpeakerWaveIcon } from '../ui/Icons';

const ReaderControls: React.FC<{
    view: BookView | null;
    tts: ReturnType<typeof useGeminiTTS>;
    show: boolean;
}> = ({ view, tts, show }) => {
    const [progress, setProgress] = useState(0);
    const [location, setLocation] = useState('');

    useEffect(() => {
        if (!view) return;
        const handleRelocate = (e: any) => {
            const { fraction, location: locInfo, pageItem } = e.detail;
            setProgress(fraction);
            setLocation(pageItem ? `Page ${pageItem.label}` : `Location ${locInfo.current}`);
        };
        view.addEventListener('relocate', handleRelocate);
        return () => view.removeEventListener('relocate', handleRelocate);
    }, [view]);

    const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        view?.goToFraction(parseFloat(e.target.value));
    };

    return (
        <footer className={`fixed bottom-0 left-0 right-0 p-4 z-30 transition-transform duration-300 ease-in-out ${show ? 'translate-y-0' : 'translate-y-full'}`}>
            <div className="max-w-3xl mx-auto bg-slate-800/80 backdrop-blur-lg p-3 rounded-xl shadow-2xl">
                <div className="flex items-center space-x-4">
                    <span className="text-xs text-slate-400 w-24 truncate text-center">{location}</span>
                    <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.001"
                        value={progress}
                        onChange={handleSliderChange}
                        className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer"
                        style={{'accentColor': '#6366f1'}}
                        aria-label="Book Progress"
                    />
                     <span className="text-xs text-slate-400 w-16 text-right">{(progress * 100).toFixed(1)}%</span>
                </div>
                <div className="flex items-center justify-center space-x-6 mt-3">
                    <button onClick={() => view?.goLeft()} className="p-2 rounded-full hover:bg-slate-700/50 transition-colors" aria-label="Previous Page">
                        <ChevronLeftIcon className="h-8 w-8" />
                    </button>
                     <button onClick={tts.togglePlay} className="p-4 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg hover:shadow-indigo-500/50 transition-all" aria-label={tts.isPlaying ? 'Pause Text to Speech' : 'Play Text to Speech'}>
                        {tts.isLoading ? (
                            <svg className="animate-spin h-8 w-8 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                        ) : tts.isPlaying ? <PauseIcon className="h-8 w-8" /> : <SpeakerWaveIcon className="h-8 w-8" />}
                    </button>
                    <button onClick={() => view?.goRight()} className="p-2 rounded-full hover:bg-slate-700/50 transition-colors" aria-label="Next Page">
                        <ChevronRightIcon className="h-8 w-8" />
                    </button>
                </div>
            </div>
        </footer>
    );
};

export default ReaderControls;
