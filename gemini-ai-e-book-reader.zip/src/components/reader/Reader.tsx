
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useBook } from '../../hooks/useBook';
import { useGeminiTTS } from '../../hooks/useGeminiTTS';
import type { Book } from '../../lib/ebook-engine/types';
import Header from './Header';
import Sidebar from './Sidebar';
import ReaderControls from './ReaderControls';

const Reader: React.FC<{ book: Book }> = ({ book }) => {
    const { view, loading } = useBook(book);
    const containerRef = useRef<HTMLDivElement>(null);
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const [showUI, setShowUI] = useState(true);
    const timerRef = useRef<number | null>(null);

    const tts = useGeminiTTS(view);

    const hideUI = useCallback(() => {
        if (timerRef.current) clearTimeout(timerRef.current);
        timerRef.current = window.setTimeout(() => setShowUI(false), 3000);
    }, []);

    const handleMouseMove = useCallback(() => {
        setShowUI(true);
        hideUI();
    }, [hideUI]);

    useEffect(() => {
        console.log('[EBookReader] Reader component mounted.');
    }, []);

    useEffect(() => {
        const container = containerRef.current;
        if (!container || !view) return;
        
        console.log('[EBookReader:Reader] Attaching book view to the DOM.');
        container.innerHTML = '';
        container.appendChild(view.renderer);

        hideUI();

        window.addEventListener('mousemove', handleMouseMove);
        return () => {
             console.log('[EBookReader:Reader] Cleaning up book view from DOM.');
             if (timerRef.current) clearTimeout(timerRef.current);
             window.removeEventListener('mousemove', handleMouseMove);
        }
    }, [view, hideUI, handleMouseMove]);

    if (loading) {
        return (
            <div className="flex items-center justify-center h-screen text-slate-300">
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Loading book...
            </div>
        );
    }

    return (
        <div className="h-screen w-screen overflow-hidden bg-slate-900">
            <Header book={book} onMenuClick={() => setIsSidebarOpen(true)} show={showUI} />
            <Sidebar book={book} isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} view={view} />
            
            <div ref={containerRef} className="h-full w-full" id="viewer"></div>
            
            <ReaderControls view={view} tts={tts} show={showUI} />
        </div>
    );
};

export default Reader;