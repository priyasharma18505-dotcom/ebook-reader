
import React, { useState, useEffect, useRef } from 'react';
import type { Book, BookView } from '../../lib/ebook-engine/types';
import { createTOCView } from '../../lib/ebook-engine/ui/tree';

const Sidebar: React.FC<{ book: Book; isOpen: boolean; onClose: () => void; view: BookView | null }> = ({ book, isOpen, onClose, view }) => {
    const [currentTocItem, setCurrentTocItem] = useState<any>(null);
    const [isDownloading, setIsDownloading] = useState(false);
    const tocContainerRef = useRef<HTMLDivElement>(null);
    const tocRef = useRef<{ setCurrentHref: (href: string) => void } | null>(null);

    const handleDownloadTxt = async () => {
        if (!book) return;
        setIsDownloading(true);
        try {
            let fullText = '';
            const sectionsWithText = book.sections.filter(s => s.createDocument);

            if (sectionsWithText.length === 0) {
                alert('This book format does not contain extractable text.');
                setIsDownloading(false);
                return;
            }

            for (const section of sectionsWithText) {
                if (typeof section.createDocument !== 'function') continue;
                
                const doc = await section.createDocument();
                if (doc.body) {
                    fullText += doc.body.innerText + '\n\n';
                }
            }

            if (fullText.trim()) {
                const blob = new Blob([fullText], { type: 'text/plain;charset=utf-8' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                const title = (book.metadata?.title as string || 'ebook').replace(/[/\\?%*:|"<>]/g, '-');
                a.href = url;
                a.download = `${title}.txt`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            } else {
                alert('Could not extract any text from this book.');
            }
        } catch (error) {
            console.error("Failed to download book as TXT:", error);
            alert('An error occurred while preparing the text file.');
        } finally {
            setIsDownloading(false);
        }
    };

    useEffect(() => {
        if (!view) return;
        const handleRelocate = (e: any) => {
            setCurrentTocItem(e.detail.tocItem);
            if (tocRef.current && e.detail.tocItem?.href) {
                tocRef.current.setCurrentHref(e.detail.tocItem.href);
            }
        };
        view.addEventListener('relocate', handleRelocate);
        return () => view.removeEventListener('relocate', handleRelocate);
    }, [view]);

    useEffect(() => {
        if (isOpen && tocContainerRef.current && book.toc && book.toc.length > 0) {
            const tocInstance = createTOCView(book.toc, href => {
                view?.goTo(href);
                onClose();
            });
            tocRef.current = tocInstance;
            tocContainerRef.current.innerHTML = '';
            tocContainerRef.current.appendChild(tocInstance.element);
            if (currentTocItem?.href) {
                tocInstance.setCurrentHref(currentTocItem.href);
            }
        }
    }, [isOpen, book.toc, view, onClose, currentTocItem]);
    
    return (
        <>
            <div className={`fixed inset-0 bg-black/60 z-40 transition-opacity ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={onClose}></div>
            <div className={`fixed top-0 left-0 h-full w-80 bg-slate-800/95 backdrop-blur-lg text-slate-200 shadow-2xl z-50 transform transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : '-translate-x-full'} flex flex-col`}>
                <div className="p-4 border-b border-slate-700 flex-shrink-0">
                    <h2 className="text-xl font-bold truncate" title={book.metadata?.title as string}>{book.metadata?.title as string}</h2>
                    <p className="text-sm text-slate-400 truncate">{Array.isArray(book.metadata?.author) ? book.metadata.author.map(a => a.name).join(', ') : book.metadata?.author?.name as string}</p>
                </div>
                <div className="overflow-y-auto flex-grow reader-sidebar-toc">
                    <h3 className="text-lg font-semibold mb-2 text-slate-300 px-4 pt-4">Table of Contents</h3>
                    {book.toc && book.toc.length > 0 ? (
                        <div ref={tocContainerRef} className="p-4 pt-0"></div>
                    ) : (
                        <p className="text-slate-400 px-4">No table of contents available.</p>
                    )}
                </div>
                <div className="p-4 border-t border-slate-700 flex-shrink-0 mt-auto">
                    <button 
                        onClick={handleDownloadTxt} 
                        disabled={isDownloading}
                        className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-800 disabled:cursor-not-allowed text-white font-bold py-2 px-4 rounded-lg transition-colors flex items-center justify-center shadow-lg hover:shadow-indigo-500/50"
                    >
                        {isDownloading ? (
                            <>
                                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                Downloading...
                            </>
                        ) : (
                            'Download as TXT'
                        )}
                    </button>
                </div>
            </div>
        </>
    );
};

export default Sidebar;
