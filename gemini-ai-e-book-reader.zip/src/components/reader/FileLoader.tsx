import React, { useState } from 'react';
import { BookOpenIcon } from '../ui/Icons';

const FileLoader: React.FC<{ onFileSelect: (file: File) => void }> = ({ onFileSelect }) => {
    const [isDragging, setIsDragging] = useState(false);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            onFileSelect(file);
        }
    };

    const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        setIsDragging(false);
        const file = event.dataTransfer.files?.[0];
        if (file) {
            onFileSelect(file);
        }
    };

    const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        setIsDragging(true);
    };

    const handleDragLeave = () => {
        setIsDragging(false);
    };

    return (
        <div className="flex items-center justify-center h-screen bg-slate-900 text-slate-100">
            <div
                className={`w-full max-w-lg p-8 border-2 border-dashed rounded-lg text-center transition-all duration-300 ease-in-out ${isDragging ? 'border-indigo-500 bg-slate-800/50 scale-105' : 'border-slate-700'}`}
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
            >
                <BookOpenIcon className="mx-auto h-16 w-16 text-slate-500" />
                <h2 className="mt-4 text-2xl font-bold tracking-tight">Gemini AI E-Book Reader</h2>
                <p className="mt-2 text-slate-400">Drag & drop your e-book file here, or click to select a file.</p>
                <div className="mt-6">
                    <label htmlFor="file-upload" className="cursor-pointer bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-6 rounded-lg transition-colors shadow-lg hover:shadow-indigo-500/50">
                        Select a Book
                    </label>
                    <input id="file-upload" type="file" className="hidden" onChange={handleFileChange} />
                </div>
                 <p className="mt-4 text-xs text-slate-500">Supports EPUB, MOBI, FB2, and CBZ formats.</p>
            </div>
        </div>
    );
};

export default FileLoader;