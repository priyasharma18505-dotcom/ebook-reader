import { decode, decodeAudioData } from './audio';

export class AudioPlayer {
    private audioContext: AudioContext;
    private audioSource: AudioBufferSourceNode | null = null;
    private onendedCallback: (() => void) | null = null;

    constructor(sampleRate: number = 24000) {
        this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate });
    }

    public async play(base64Audio: string, onended: () => void): Promise<void> {
        this.stop(); // Stop any currently playing audio

        this.onendedCallback = onended;

        try {
            const audioBuffer = await decodeAudioData(decode(base64Audio), this.audioContext, 24000, 1);
            const source = this.audioContext.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(this.audioContext.destination);
            
            source.onended = () => {
                if (this.audioSource === source) { // Ensure it's not an old source
                    this.audioSource = null;
                    this.onendedCallback?.();
                }
            };
            
            source.start(0);
            this.audioSource = source;
        } catch (error) {
            console.error("Error playing audio:", error);
            this.onendedCallback?.(); // Move to the next item on error
        }
    }

    public pause(): void {
        if (this.audioSource) {
            this.audioSource.onended = null; // Prevent onended from firing on manual pause
            this.audioSource.stop();
            this.audioSource = null;
        }
    }

    public stop(): void {
        if (this.audioSource) {
            this.audioSource.onended = null; // Prevent onended from firing on manual stop
            this.audioSource.stop();
            this.audioSource = null;
        }
        this.onendedCallback = null;
    }
}